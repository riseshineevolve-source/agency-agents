/* One responsive menu on Home and Guides; fails open without JavaScript. */
(function () {
  "use strict";
  function init() {
    var header=document.querySelector(".rse-global-header");
    if(!header)return;
    var toggle=header.querySelector(".rse-global-toggle");
    var menu=header.querySelector(".rse-global-nav");
    if(!toggle||!menu)return;
    function close(){
      header.classList.remove("is-open");
      toggle.setAttribute("aria-expanded","false");
    }
    function open(){
      header.classList.add("is-open");
      toggle.setAttribute("aria-expanded","true");
    }
    toggle.addEventListener("click",function(){
      if(header.classList.contains("is-open"))close();
      else open();
    });
    header.addEventListener("keydown",function(event){
      if(event.key==="Escape"&&header.classList.contains("is-open")){
        close();
        toggle.focus();
      }
    });
    menu.addEventListener("click",function(event){
      if(event.target.closest("a,button"))close();
    });
    document.addEventListener("pointerdown",function(event){
      if(!header.contains(event.target))close();
    });
    window.addEventListener("resize",function(){
      if(window.innerWidth>1160)close();
    });
    document.documentElement.classList.add("rse-nav-ready");
  }
  if(document.readyState==="loading")
    document.addEventListener("DOMContentLoaded",init,{once:true});
  else init();
})();
