from pathlib import Path
import json,hashlib,re,html
R=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
def compile_studio():
 s=(R/'source.html').read_text();lock=read(R/'source-lock.json');assert hashlib.sha256(s.encode()).hexdigest()==lock['decoded_html_sha256']
 targets=read(R/'targets.pl.json');source=read(R/'source.json')['segments'];assert [x['id'] for x in targets]==[x['id'] for x in source];t={x['id']:x['text'] for x in targets};patches=[]
 for item in read(R/'occurrences.json'):
  value=t[item['id']]
  assert not any(c in value for c in ['`',"'",'"','${','<','>','&','\\']),item['id']
  for o in item['occurrences']:
   assert s[o['start']:o['end']]==o['raw'];patches.append((o['start'],o['end'],value))
 mechanics={"split(/s+/)":r'split(/\s+/)',"'hmWordSearchStudioState'":"'hmWordSearchStudioState:pl'","'ABCDEFGHIJKLMNOPQRSTUVWXYZ'":"'AĄBCĆDEĘFGHIJKLŁMNŃOÓPQRSŚTUUVWXYZŹŻ'",'if (maxWordLength > 15)':'if (maxWordLength > 16)','this.gridSize = Math.min(Math.ceil(baseSize), 15);':'this.gridSize = Math.min(Math.ceil(baseSize), 16);','while (attempts < 20 && !success)':'while (attempts < 32 && !success)','this.gridSize = Math.min(25, this.gridSize + 1);':'this.gridSize = Math.min(35, this.gridSize + 1);'}
 for old,new in mechanics.items():
  assert s.count(old)==1,(old,s.count(old));a=s.index(old);patches.append((a,a+len(old),new))
 patches.sort();assert all(a[1]<=b[0] for a,b in zip(patches,patches[1:]));out=[];offset=0
 for a,b,v in patches:out.extend([s[offset:a],v]);offset=b
 out.append(s[offset:]);h=''.join(out);(R/'proposed.html').write_text(h)
 js='window.WORD_SEARCH_STUDIO_HTML = '+json.dumps(h,ensure_ascii=False)+';\n';(R/'inline.pl.js').write_text(js)
 report={'source_sha256':lock['sha256'],'candidate_targets_sha256':hashlib.sha256((R/'targets.pl.json').read_bytes()).hexdigest(),'decoded_html_sha256':hashlib.sha256(h.encode()).hexdigest(),'compiled_js_sha256':hashlib.sha256(js.encode()).hexdigest(),'copy_occurrences':len(patches)-len(mechanics),'locale_mechanics':mechanics,'status':'LOCAL_PREVIEW_ONLY'};(R/'compile-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n');return js
if __name__=='__main__':compile_studio()
