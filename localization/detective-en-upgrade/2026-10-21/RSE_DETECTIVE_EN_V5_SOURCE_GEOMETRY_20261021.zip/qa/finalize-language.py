from pathlib import Path
import json,hashlib,subprocess
R=Path('detective-upgrade');C=R/'candidate/candidate.json';h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text());save=lambda p,x:p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
c=read(C);ch=h(C);run=read(R/'run-v4/run.json');native=read(R/'qa/review-native-voice.json');truth=read(R/'qa/review-truth-mechanics.json');logic=read(R/'qa/review-story-logic.json');assert native['candidate_file_sha256']==truth['candidate_sha256']==logic['candidate_sha256']==ch
assert native['decision']=='KEEP' and truth['status']=='PASS' and logic['status'] in ['PASS','KEEP']
ledger=read(R/'candidate/change-ledger.json');issues=[]
for i,item in enumerate(ledger,1):
 ids=item.get('actual_changed_ids',[]);issues.append({'id':f'editorial-{i:03}','segment_id':ids[0] if ids else None,'classification':'FIX' if ids else 'KEEP','final_classification':'KEEP','evidence':'Actual independent native/voice, truth/mechanics and globalstory review accepted exactcandidate; see boundreviewreports.','resolution':item.get('defect','Targeted source defect resolved without puzzle truth change'),'source_folio':item['page']})
source_debt={'id':'source-photo-caption-chronology','segment_id':None,'status':'OWNER_GATE','evidence':'Protected Case03 PhotoB caption LATER FILE071 versus narrative describing071asolderfile. Existing source ambiguity preserved; no new photo/puzzle facts invented. Consumer must confirm caption means retrieval/attachment order or approve neutral label before release.'}
save(R/'run-v4/issue-ledger.json',{'run_sha256':run['manifest_sha256'],'candidate_sha256':ch,'diagnostic':'COMPLETE','issues':issues,'source_ambiguities':[source_debt]})
reviews=[]
for stage,file,reviewer in [('native_language','review-native-voice.json','detective_voice'),('audience','review-native-voice.json','detective_voice'),('meaning','review-truth-mechanics.json','detective_source_audit'),('logic','review-story-logic.json','detective_story_logic')]:reviews.append({'stage':stage,'status':'PASS','candidate_sha256':ch,'reviewer':reviewer,'evidence':'Actual full candidate prose diagnostic + changed-unit/dependency closure review; exactcandidate binding checked. Existing source caption gate remains separate.','evidence_file':file,'evidence_sha256':h(R/'qa'/file)})
save(R/'qa/reviews.cli.json',{'candidate_sha256':ch,'reviews':reviews})
out=R/'qa/FINAL_LANGUAGE_CHECK.json'
if out.exists():out.unlink()
r=subprocess.run(['python3','rse/scripts/rse-language.py','check','--run',str(R/'run-v4'),'--candidate',str(C),'--reviews',str(R/'qa/reviews.cli.json'),'--output',str(out)],text=True,capture_output=True);assert r.returncode==0,r.stderr+r.stdout
x=read(out);print(json.dumps({k:x[k] for k in ['status','deterministic_qa','candidate_sha256','specialist_reviews']}))
