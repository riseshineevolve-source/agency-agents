#!/usr/bin/env python3
"""Compile source-mapped native PL into an isolated exact-layout website preview.
Never edits website sources, current /pl pages, approved Guides or product data.
"""
from pathlib import Path
from lxml import html, etree
from urllib.parse import urljoin,urlsplit
import argparse,hashlib,json,re,os,importlib.util
ORIGIN='https://rise-shine-evolve-learning-hub.com'
TOKEN=re.compile(r'\{slot_(\d+)\}')
def sha(b):return hashlib.sha256(b).hexdigest()
def normalized(s):return re.sub(r'\s+',' ',s).strip()
def page_path(url):return (url.rstrip('/')+'/index.html').lstrip('/') if not url.endswith('.html') else url.lstrip('/')
def structural(doc):
 return [(n.tag,dict(n.attrib)) for n in doc.iter() if isinstance(n.tag,str) and n.tag not in ['script']]
def build(source,work,out,candidate,dynamic_candidate=None):
 if out.exists():raise ValueError('Preview already exists; use a new versioned destination')
 units=json.loads((work/'analysis-units.json').read_text());byid={u['id']:u for u in units}
 rows=json.loads(candidate.read_text());rows=rows['segments'] if isinstance(rows,dict) else rows
 targets={r['id']:r['text'] for r in rows}
 assert len(targets)==len(rows)==len(units),'Duplicate or missing target IDs'
 assert set(targets)==set(byid),'Incomplete segment coverage'
 occ=json.loads((work/'occurrences.json').read_text());pages=json.loads((work/'source-pages.json').read_text());routes={x['path']:'pl/'+x['path'] for x in pages}
 report={'pages':[],'preserved_guides':True,'production_source_changed':False,'release_authorized':False,'candidate_sha256':sha(candidate.read_bytes()),'dynamic_status':'SUPPLEMENT_REQUIRED'}
 dyn=None;dynamic={};static={};receipts=[]
 if dynamic_candidate:
  spec=importlib.util.spec_from_file_location('dynamic_compile',Path(__file__).resolve().parent.parent/'website-dynamic/compile.py');dyn=importlib.util.module_from_spec(spec);spec.loader.exec_module(dyn)
  dynamic,static=dyn.build_maps(dynamic_candidate,candidate)
  report['dynamic_status']='SOURCE_MAPPED';report['dynamic_candidate_sha256']=sha(dynamic_candidate.read_bytes())
 grouped={}
 for o in occ:grouped.setdefault(o['page'],[]).append(o)
 for page in pages:
  src=source/page['path'];raw=src.read_bytes();assert sha(raw)==page['sha256'],'Stale source '+str(src)
  prepared=raw.decode()
  if dyn and page['path'] in dyn.read(dyn.ROOT/'DYNAMIC_SOURCE_FILES.json'):
   prepared,receipt=dyn.apply_to_file(page['path'],prepared,dynamic,static);receipts.append(receipt)
  doc=html.fromstring(prepared);original_tags=[n.tag for n in doc.iter() if isinstance(n.tag,str)]
  original_assets=[(n.tag,a,n.get(a)) for n in doc.iter() if isinstance(n.tag,str) for a in ['src','poster'] if n.get(a)]
  count=0
  for o in grouped.get(page['path'],[]):
   value=targets[o['id']];assert isinstance(value,str) and value.strip(),o['id']
   nodes=doc.xpath(o['xpath']);assert len(nodes)==1,(page['path'],o['xpath']);node=nodes[0]
   if o['kind']=='block':
    slots=o['slots'];markers=TOKEN.findall(value)
    if len(slots)>1:
     assert markers==[str(i) for i in range(1,len(slots)+1)],(o['id'],'wrong/reordered slot markers')
     pieces=TOKEN.split(value);assert not pieces[0].strip(),o['id'];chunks=[pieces[i+1] for i in range(1,len(pieces),2)]
    else:
     assert not markers,o['id'];chunks=[value.strip()]
    for slot,text in zip(slots,chunks):
     assert text,(o['id'],'empty slot');n=doc.xpath(slot['xpath'])[0]
     # Native writer controls spacing at inline boundaries; punctuation stays exact.
     setattr(n,slot['field'],text)
   elif o['kind']=='slot':setattr(node,o['field'],value)
   elif o['kind']=='attribute':node.set(o['attribute'],value)
   elif o['kind']=='metadata':
    if o['attribute']:node.set(o['attribute'],value)
    else:node.text=value
   count+=1
  doc.set('lang','pl');doc.set('translate','no')
  # Reviewed translation changes language strings; all EN structure stays intact.
  assert [n.tag for n in doc.iter() if isinstance(n.tag,str)]==original_tags
  dest=out/routes[page['path']];dest.parent.mkdir(parents=True,exist_ok=True)
  original_url=ORIGIN+'/'+page['path'].removesuffix('index.html')
  for n in doc.xpath('//*[@href or @src or @poster or @action]'):
   for attr in ['href','src','poster','action']:
    old=n.get(attr)
    if not old or old.startswith(('mailto:','tel:','javascript:','data:','#')):continue
    resolved=urljoin(original_url,old);u=urlsplit(resolved)
    if attr=='href' and u.netloc==urlsplit(ORIGIN).netloc:
     plain=page_path(u.path)
     if plain.startswith('pl/'):plain=plain[3:]
     if plain in routes:
      target=out/routes[plain];new=os.path.relpath(target,dest.parent)
      if u.fragment:new+='#'+u.fragment
      n.set(attr,new)
     elif u.path.startswith('/pl/guides/') or u.path.startswith('/guides/'):
      n.set(attr,ORIGIN+'/pl/'+u.path.removeprefix('/pl/').removeprefix('/'))
     else:n.set(attr,resolved)
    elif attr in ['src','poster']:
     if dyn and u.path in ['/assets/js/rse-experience-hub.js','/assets/word-search-studio/inline.js']:
      n.set(attr,os.path.relpath(out/'pl'/u.path.lstrip('/'),dest.parent))
     else:n.set(attr,resolved)
  for m in doc.xpath('//meta[@name="robots"]'):m.set('content','noindex,follow')
  for m in doc.xpath('//link[@rel="canonical"]'):m.set('href',ORIGIN+'/pl/'+page['path'].removesuffix('index.html'))
  # Preserve source schema entities; localize values only when visible text has an exact mapped equivalent.
  exact={byid[k]['text']:v for k,v in targets.items() if not TOKEN.search(byid[k]['text'])}
  for k,u in byid.items():
   # FAQ schema often duplicates a single inline slot from a composed visible unit.
   if TOKEN.search(u['text']):
    source_parts=TOKEN.split(u['text']);target_parts=TOKEN.split(targets[k])
    for i in range(2,len(source_parts),2):
     exact[normalized(source_parts[i])]=normalized(target_parts[i])
  def localize_schema(v):
   if isinstance(v,dict):
    # Website language does not turn an English book or future native app into
    # a released Polish product edition.
    product_language=v.get('@type')=='Book' or (v.get('@type')=='SoftwareApplication' and page['path'] in ['adventure-app/index.html','unstoppable-app/index.html','apps/gentle-steps/index.html'])
    return {k:(c if product_language else 'pl') if k=='inLanguage' else localize_schema(c) for k,c in v.items()}
   if isinstance(v,list):return [localize_schema(x) for x in v]
   if isinstance(v,str):
    if v.startswith(ORIGIN+'/'):
     u=urlsplit(v);plain=page_path(u.path)
     if plain in routes:return ORIGIN+'/pl/'+plain.removesuffix('index.html')+('?' +u.query if u.query else '')+('#'+u.fragment if u.fragment else '')
    return exact.get(normalized(v),v)
   return v
  schema_unmatched=[]
  for script in doc.xpath('//script[@type="application/ld+json"]'):
   try:val=json.loads(script.text or '');script.text=json.dumps(localize_schema(val),ensure_ascii=False)
   except json.JSONDecodeError:schema_unmatched.append('Source JSON-LD parse requires source repair')
  # A switch on PL must return to its English counterpart; do not point to another PL clone.
  for a in doc.xpath('//a[contains(@class,"lang") or contains(@aria-label,"polska wersja")]'):
   if normalized(a.text_content()).upper()=='PL':
    a.text='EN';a.set('href',original_url);a.set('aria-label','English version')
  dest.write_bytes(html.tostring(doc,encoding='utf-8',doctype='<!doctype html>'))
  report['pages'].append({'source':page['path'],'target':routes[page['path']],'source_sha256':page['sha256'],'target_sha256':sha(dest.read_bytes()),'mapped_occurrences':count,'same_element_structure':True,'source_asset_references':len(original_assets),'schema_issues':schema_unmatched})
 if dyn:
  for rel in ['assets/js/rse-experience-hub.js','data/rse-format-options.json']:
   text=(source/rel).read_text()
   if rel.endswith('.json'):
    value,n=dyn.apply_json(rel,json.loads(text),dynamic,static);text=json.dumps(value,ensure_ascii=False,indent=2)+'\n';receipts.append({'path':rel,'pointer_changes':n})
   else:text,receipt=dyn.apply_to_file(rel,text,dynamic,static);receipts.append(receipt)
   target=out/'pl'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
  editorial={'world-01':('rse-world-01-editorial.txt','.rse-rich-story'),'world-02':('rse-world-02-editorial.txt','.rse-rich-story'),'happy-me':('rse-happy-me-editorial.txt','.rse-rich-story'),'detective':('rse-detective-dossier.txt','.hm-case-dialog__inner')}
  for route,(name,selector) in editorial.items():
   d=html.fromstring((out/'pl/experience'/route/'index.html').read_bytes());nodes=d.xpath('//*[contains(concat(" ",normalize-space(@class)," ")," '+selector[1:]+' ")]')
   assert len(nodes)==1,(route,selector,len(nodes))
   target=out/'pl/assets/content'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(html.tostring(nodes[0],encoding='utf-8'))
  report['dynamic_patch_receipts']=receipts
 (out/'BUILD_REPORT.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 (out/'index.html').write_text('<!doctype html><html lang="pl"><meta charset="utf-8"><meta name="robots" content="noindex"><title>RSE: polski podgląd</title><body><h1>RSE: polska wersja do oceny</h1><p>Teksty na podstawie zamrożonego źródła EN. Podgląd redakcyjny.</p><a href="pl/index.html">Otwórz stronę główną</a><ul>'+''.join('<li><a href="'+r['target']+'">'+r['target']+'</a></li>' for r in report['pages'])+'</ul></body></html>')
 return report
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--source',type=Path,default=Path('website-source'));ap.add_argument('--work',type=Path,default=Path('website-work'));ap.add_argument('--candidate',type=Path,required=True);ap.add_argument('--dynamic-candidate',type=Path);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 r=build(a.source,a.work,a.output,a.candidate,a.dynamic_candidate);print(json.dumps({'pages':len(r['pages']),'candidate':r['candidate_sha256']}))
