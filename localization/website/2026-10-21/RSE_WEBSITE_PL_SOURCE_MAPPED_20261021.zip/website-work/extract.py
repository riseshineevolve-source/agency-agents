from pathlib import Path
from lxml import html,etree
import json,re,hashlib
ROOT=Path('website-source')
EXCLUDED={'script','style','noscript','svg','path','title'}
# Keep complete paragraphs and headings together; preserve inline element boundaries
# as numbered tokens so the EN DOM can be reused without new layout elements.
BLOCKS={'p','h1','h2','h3','h4','h5','h6','li','button','label','option','summary','figcaption','dt','dd','a'}
files=[];segments=[];by_key={};occ=[]
protected_names=['Rise.Shine.Evolve.','Rise.Shine.Evolve','RISE.SHINE.EVOLVE','The Happy Makers','THE HAPPY MAKERS','Mimi','Luli','Dilo','Alio','Nini','Bibi','Level Up Your Brain','World 01','World 02','The Confident, Mindful & Happy Me Adventure','Project Unstoppable','Optical Animals','Optical Halloween','Detective Academy','Google Play','Amazon','Android','Instagram','TikTok','YouTube','Facebook']
def norm(s):return re.sub(r'\s+',' ',s).strip()
def excluded(n):return any(a.tag in EXCLUDED for a in [n,*n.iterancestors()] if isinstance(a.tag,str))
def add(text,entry,context='',tokens=None):
 text=norm(text)
 if not text or not re.search('[A-Za-z]',text):return
 if text in ['EN','PL','RSE','MENU','RISE','SHINE','EVOLVE'] or text in protected_names:return
 key=(text,tuple(tokens or []))
 if key not in by_key:
  sid='web.'+str(len(segments)+1).zfill(4);by_key[key]=sid
  segments.append({'id':sid,'text':text,'protected_tokens':tokens or [],'context':context,'first_route':entry['page'],'kind':entry['kind']})
 sid=by_key[key];entry['id']=sid;occ.append(entry)
 return sid
for p in sorted(ROOT.rglob('*.html')):
 if 'assets' in p.parts:continue
 rel=str(p.relative_to(ROOT));doc=html.fromstring(p.read_bytes());tree=doc.getroottree();handled=set()
 # top-level semantic block only, recursively reject parents with nested blocks.
 for n in doc.xpath('//body//*'):
  if not isinstance(n.tag,str) or excluded(n) or n in handled:continue
  if n.tag in BLOCKS and not any(isinstance(c.tag,str) and c.tag in BLOCKS for c in n.iterdescendants()):
   # Only inline subtrees, no flow-section or embedded script.
   if any(c.tag in ['div','section','article','table','ul','ol','script','style','svg'] for c in n.iterdescendants() if isinstance(c.tag,str)):continue
   slots=[];parts=[];tokens=[];i=0
   for elem in n.iter():
    if not isinstance(elem.tag,str):continue
    if elem.text and norm(elem.text):
     i+=1;tok='{slot_'+str(i)+'}';tokens.append(tok);parts.extend([tok,norm(elem.text)]);slots.append({'xpath':tree.getpath(elem),'field':'text'})
    # tails must follow subtree, handled through a separate traversal below
   # Exact document-order text slot walk.
   slots=[];parts=[];tokens=[]
   def walk(elem):
    if elem.text and norm(elem.text):
     tok='{slot_'+str(len(slots)+1)+'}';tokens.append(tok);parts.extend([tok,norm(elem.text)]);slots.append({'xpath':tree.getpath(elem),'field':'text'})
    for c in elem:
     if isinstance(c.tag,str):walk(c)
     if c.tail and norm(c.tail):
      tok='{slot_'+str(len(slots)+1)+'}';tokens.append(tok);parts.extend([tok,norm(c.tail)]);slots.append({'xpath':tree.getpath(c),'field':'tail'})
   walk(n)
   if not slots:continue
   context=norm(n.text_content())
   if len(slots)==1:
    text=context;tokens=[]
   else:text=' '.join(parts)
   add(text,{'page':rel,'kind':'block','xpath':tree.getpath(n),'slots':slots},context,tokens)
   handled.update(n.iter())
 for n in doc.xpath('//body//*'):
  if not isinstance(n.tag,str) or excluded(n):continue
  for field in ['text','tail']:
   if field=='text' and n in handled:continue
   if field=='tail' and n.getparent() in handled:continue
   if field=='tail' and n.getparent() is None:continue
   s=getattr(n,field)
   if s and norm(s):add(s,{'page':rel,'kind':'slot','xpath':tree.getpath(n),'field':field},norm(n.getparent().text_content())[:400] if n.getparent() is not None else '')
 for n in doc.xpath('//*'):
  if not isinstance(n.tag,str) or excluded(n):continue
  for attr in ['alt','title','aria-label','placeholder']:
   if n.get(attr):add(n.get(attr),{'page':rel,'kind':'attribute','xpath':tree.getpath(n),'attribute':attr},n.tag+' '+attr)
 for n in doc.xpath('//head/title|//head/meta[@name="description"]|//head/meta[@property="og:title"]|//head/meta[@property="og:description"]|//head/meta[@name="twitter:title"]|//head/meta[@name="twitter:description"]'):
  s=n.text if n.tag=='title' else n.get('content')
  add(s,{'page':rel,'kind':'metadata','xpath':tree.getpath(n),'attribute':None if n.tag=='title' else 'content'},'SEO '+(n.get('name') or n.get('property') or 'title'))
 files.append({'path':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
# Only source text + deterministic mechanics tokens enter tool intake; context separately for analyst.
Path('website-work/source.json').write_text(json.dumps({'language':'en','segments':[{'id':s['id'],'text':s['text'],'protected_tokens':s['protected_tokens']} for s in segments]},ensure_ascii=False,indent=2)+'\n')
Path('website-work/analysis-units.json').write_text(json.dumps(segments,ensure_ascii=False,indent=2)+'\n')
Path('website-work/occurrences.json').write_text(json.dumps(occ,ensure_ascii=False,indent=2)+'\n')
Path('website-work/source-pages.json').write_text(json.dumps(files,indent=2)+'\n')
print({'pages':len(files),'unique_segments':len(segments),'text_chars':sum(len(s['text']) for s in segments),'occurrences':len(occ)})
