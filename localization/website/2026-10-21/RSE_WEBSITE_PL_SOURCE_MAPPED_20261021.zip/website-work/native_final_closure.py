import json,hashlib,re
from pathlib import Path
p=Path('website-work/targets.pl.json');raw=p.read_bytes();data=json.loads(raw);ids=set(json.loads(Path('website-work/native-closure-ids.json').read_text()))
a=json.loads(Path('website-work/review-native-batch01.json').read_text());b=json.loads(Path('website-work/review-native-rest.json').read_text());prev={r['id']:r for r in a['reviews']+b['reviews']}
rev=[]
for s in data:
 h=hashlib.sha256(s['text'].encode()).hexdigest();n=int(s['id'][4:]);changed=h!=prev[s['id']]['sha256'];targeted=n in ids
 r={'id':s['id'],'sha256':h,'status':'KEEP','basis':'Final targeted reread, including composed slot text and adjacent units.' if targeted else 'Prior full Polish-only review retained: exact segment hash unchanged.'}
 if changed and not targeted: r.update(status='REQUIRES_REVIEW',basis='Changed since reviewed hash; not included in final targeted reread.')
 if s['id'] in ['web.0146','web.0911','web.0931']:r['note']='Age is source/owner-controlled; no independent factual choice made.'
 if s['id'] in ['web.0338','web.0339']:r['note']='Planowane retained as explicit locked status label.'
 if s['id']=='web.1134' and 'angielskich' in s['text']:
  r.update(status='FIX',phrase='angielskich',reason='Polish directory routes are locale-specific; English qualifier misdescribes the index.',minimal_fix='Delete angielskich. Root explicitly authorized this narrow locale adaptation.')
 rev.append(r)
out={'role':'Independent Native Polish / Anti-AI + audience and internal logic review','candidate_sha256':hashlib.sha256(raw).hexdigest(),'scope':{'total_segments':len(data),'previously_read_all_in_Polish':True,'final_targeted_reread':len(ids),'target_selection':'All changed units against original reviewed segment hashes, every prior FIX, and their immediate numeric neighbors.','source_English_seen':False,'candidate_edited':False},'counts':{k:sum(r['status']==k for r in rev) for k in ['KEEP','FIX','BLOCK','REQUIRES_REVIEW']},'global_invariants':{'unique_ids':len({s['id'] for s in data}),'legacy_Gratisy_labels':sum('Gratis' in s['text'] for s in data),'long_dash_sentence_hinges':sum(bool(re.search('[—―]',s['text'])) for s in data),'malformed_slot_tokens':sum(bool(re.search(r'\{slot(?!_\d+\})',s['text'])) for s in data),'slot_join_review':'Targeted changed units read as composed Polish with inline formatting markers stripped; no material join failures remaining.'},'limits':['Review covers Polish native language, audience clarity and internal reading logic. It is not source-fidelity signoff, legal advice, human panel approval, owner approval or global publication PASS.','Source/owner product-age and status gates retained.','Dynamic551 and subsequent legal64 changes excluded until separately supplied.'],'reviews':rev}
Path('website-work/review-native-final.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');print(out['candidate_sha256']);print(out['counts'])
