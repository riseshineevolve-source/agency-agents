import json, hashlib, re
from pathlib import Path
p=Path('website-work/batches/batch01/targets.pl.json')
data=json.loads(p.read_text())
issues={
'web.0009':('Gratisy','Niespójna nazwa pozycji nawigacji wobec ustalonej etykiety.','Darmowe materiały'),
'web.0027':('Zajrzyj po Gratisy','Niespójna etykieta i nienaturalne połączenie „zajrzyj po”.','Zobacz darmowe materiały'),
'web.0045':('Gratisy','Niespójna nazwa pozycji nawigacji wobec ustalonej etykiety.','Darmowe materiały'),
'web.0050':('Pracujemy nad dopracowaniem aplikacji na Androida z rodziną Happy Makers przed jej wydaniem.','Ciężkie powtórzenie pracy i dopracowania; szyk może sugerować wspólną pracę z rodziną postaci.','Dopracowujemy przed wydaniem aplikację na Androida, w której towarzyszy Wam rodzina Happy Makers.'),
'web.0057':('Trwają prace nad dopracowaniem go przed wydaniem.','Urzędowe, niejasne „go” odnoszące się do projektu zamiast aplikacji.','Dopracowujemy aplikację przed wydaniem.'),
'web.0075':('Zwroty i refundacje','„Refundacja” kojarzy się z dofinansowaniem kosztów, a nie zwykłym oddaniem pieniędzy za zakup.','Zwroty i zwrot pieniędzy'),
'web.0107':('z niezależnym statusem publikacji i zakupu','Nienaturalna abstrakcyjna konstrukcja; zakup nie ma tu własnego „statusu”.','Każde ma osobny termin wydania i będzie kupowane oddzielnie.'),
'web.0133':('Uważna podróż przez adwent, która przybliża Was do siebie poprzez łagodne codzienne aktywności.','Kumulacja kalkowanych przymiotników i zwrot „łagodne aktywności” nie brzmią jak polski opis rodzinnej książki.','Adwentowa podróż, która zbliża Was do siebie dzięki prostym codziennym zabawom i chwilom uważności.'),
'web.0136':('24 krótkie codzienne aktywności, które mają znaczenie.','Puste marketingowe „które mają znaczenie” nie mówi rodzinie, co otrzyma.','24 krótkie zadania, po jednym na każdy dzień adwentu.'),
'web.0187':('ruszasz tropem śledztwa','Idzie się tropem wskazówek lub sprawcy, nie śledztwa.','ruszasz ze śledztwem'),
'web.0189':('jedno powiązane śledztwo','„Powiązane” wymaga czegoś, z czym śledztwo jest powiązane; samodzielnie brzmi jak kalka.','jedno spójne śledztwo'),
'web.0194':('dobrowolny system 3 poziomów podpowiedzi','Dobrowolne jest korzystanie z podpowiedzi, nie sam system; techniczny szyk zaciemnia prostą funkcję.','system podpowiedzi na 3 poziomach, z którego możesz skorzystać{slot_3}, gdy wskazówka okaże się zbyt trudna.'),
'web.0200':('Utknął Ci trop?','Niepoprawne połączenie wyrazów; utknąć może detektyw, nie trop.','Śledztwo utknęło w miejscu?'),
'web.0226':('Oficjalna przednia okładka','„Przednia okładka” jest techniczną kalką w zwykłym opisie ilustracji.','Oficjalna okładka'),
'web.0236':('30 powiązanych akt sprawy','Liczba pojedyncza „sprawy” sugeruje akta jednej sprawy, choć opis mówi o 30 powiązanych sprawach.','Akta 30 powiązanych spraw'),
'web.0253':('Chcesz mu pomóc ciepło','Nienaturalne połączenie czasownika z przysłówkiem.','Chcesz je wesprzeć z czułością'),
'web.0254':('zestaw narzędzi do codziennej odwagi','Abstrakcyjne „narzędzia do odwagi” brzmią jak mechaniczna kalka coachingowa.','zestaw zadań, które pomagają nabierać odwagi'),
'web.0256':('by stawać się {slot_4}najlepszą wersją siebie.','Coachingowy frazes i presja na bycie „najlepszym” osłabiają ciepły ton do dziecka.','i {slot_4}coraz śmielej z nich korzystać.'),
'web.0263':('stawiamy cele','W polszczyźnie cele się wyznacza lub stawia sobie.','wyznaczamy cele'),
'web.0265':('Twoim własnym, wielokrotnie przydatnym {slot_3}podręcznym zestawem sposobów','Nagromadzenie określeń i nienaturalne „wielokrotnie przydatny” utrudniają lekturę.','Twoim {slot_3}podręcznym zbiorem sposobów na trudne chwile'),
'web.0268':('Odkryjcie, ile potrafi Twoje dziecko','Niespójność liczby odbiorców w jednym CTA.','Odkryj, ile potrafi Twoje dziecko'),
'web.0275':('Zobacz w Amazon','Nienaturalny przyimek w polskim CTA do serwisu zakupowego.','Zobacz na Amazonie'),
'web.0276':('Oficjalna przednia okładka','„Przednia okładka” jest techniczną kalką w zwykłym opisie ilustracji.','Oficjalna okładka'),
'web.0323':('zamienić błędy w ćwiczenie i rozwijanie umiejętności','Nienaturalne połączenie: błędów nie zamienia się w „rozwijanie”.','uczyć się na błędach i rozwijać umiejętności'),
'web.0334':('oparte na rzeczywistych pojęciach','„Rzeczywiste pojęcia” niczego jasno nie wyjaśniają i brzmią jak kalka.','przystępnie wyjaśniające pojęcia z psychologii'),
'web.0336':('by coraz rzadziej zdawać się na odruchową reakcję','Podmiotem bezokolicznika pozostaje rodzic („pomóż”), choć chodzi o reakcje dziecka.','by coraz rzadziej reagowało odruchowo'),
'web.0338':('Aplikacja • Planowane','Niezgodność rodzaju w etykiecie aplikacji.','Aplikacja • W przygotowaniu'),
'web.0339':('Planowane','Niejasna, samodzielna etykieta statusu.','W przygotowaniu'),
'web.0341':('Oficjalna przednia okładka','„Przednia okładka” jest techniczną kalką w zwykłym opisie ilustracji.','Oficjalna okładka'),
'web.0353':('sposoby na emocje i codzienne zwyczaje','„Sposoby na zwyczaje” jest niejasne i brzmi jak skrót po mechanicznym przekładzie.','sposoby radzenia sobie z emocjami i dbania o codzienne zwyczaje'),
'web.0355':('grający w Minecraft','W polskim zdaniu tytuł gry ma tu naturalną odmianę.','grający w Minecrafta'),
'web.0361':('Surowe myśli o sobie','Nienaturalne połączenie; surowa może być ocena.','Surowe ocenianie siebie'),
'web.0386':('Oficjalna przednia okładka','„Przednia okładka” jest techniczną kalką w zwykłym opisie ilustracji.','Oficjalna okładka')
}
reviews=[]
for x in data:
 z={'id':x['id'],'sha256':hashlib.sha256(x['text'].encode()).hexdigest(),'status':'FIX' if x['id'] in issues else 'KEEP'}
 if x['id'] in issues:
  a,b,c=issues[x['id']];z.update(phrase=a,reason=b,minimal_fix=c)
 reviews.append(z)
out={'reviewer_role':'Native Polish / Anti-AI + audience reviewer','scope':{'input':str(p),'segments_reviewed':len(data),'source_language_seen':False,'other_batches_reviewed':False,'method':'Read every Polish segment independently; inline slot markers ignored for composed reading. Headings and labels allowed as fragments. Material issues only.'},'counts':{'KEEP':len(data)-len(issues),'FIX':len(issues),'BLOCK':0},'notes':['No claims of human native panel, owner approval or overall publication PASS.','FIX proposals are targeted editorial guidance, not applied candidate edits.','No long-dash sentence hinges observed.','Inline markers do not themselves form visible copy; no broken within-sentence joins observed beyond flagged phrasing.'],'reviews':reviews}
Path('website-work/review-native-batch01.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(out['counts'])
