from pathlib import Path
import re,json,subprocess,hashlib
# Reuse only our own pure lexical helper definitions (not extractor body).
ns={};exec(Path('website-dynamic/extract.py').read_text().split('allraw=[]')[0],ns)
literals,named_range=ns['literals'],ns['named_range']
s=Path('website-source/index.html').read_text();items=[]
for name in ['readyMottosLibrary','internalWords','deepTemplates']:
 a,b=named_range(s,name)
 for st,en,q,raw in literals(s,a,b):
  if '${' in raw:raise ValueError('Unexpected interpolation')
  prior=s[max(a,st-100):st];m=re.search(r'(\w+)\s*:\s*$',prior)
  if name=='readyMottosLibrary' and (not m or m.group(1) not in ['text','hint']):continue
  items.append({'page':'index.html','scope':name,'field':m.group(1) if m else name,'start':st,'end':en,'quote':q,'raw':raw})
p=subprocess.run(['node','-e',"const fs=require('fs'),vm=require('vm');console.log(JSON.stringify(JSON.parse(fs.readFileSync(0,'utf8')).map(x=>vm.runInNewContext('('+x+')',Object.create(null),{timeout:100}))));"],input=json.dumps([x['raw'] for x in items]),capture_output=True,text=True,check=True)
values=json.loads(p.stdout);rows=[]
for i,(item,val) in enumerate(zip(items,values),1):
 item['id']=f'motto.{i:04d}';item['value']=val
 rows.append({'id':item['id'],'text':val,'protected_tokens':re.findall(r'\{v[12]\}',val)})
r=Path('website-dynamic/motto')
(r/'source.json').write_text(json.dumps({'language':'en','segments':rows},ensure_ascii=False,indent=2)+'\n')
(r/'analysis-units.json').write_text(json.dumps([{**x,'kind':it['field'],'scope':it['scope']} for x,it in zip(rows,items)],ensure_ascii=False,indent=2)+'\n')
(r/'occurrences.json').write_text(json.dumps(items,ensure_ascii=False,indent=2)+'\n')
(r/'source-lock.json').write_text(json.dumps({'source':'index.html','sha256':hashlib.sha256(s.encode()).hexdigest(),'mechanics':'14 templates share 21 selectable values and arbitrary user input. Polish templates must work without inflecting placeholder values; preserve v1,v2 and line breaks; no new family advice.'},indent=2)+'\n')
print(len(rows),sum(len(x['text']) for x in rows))
