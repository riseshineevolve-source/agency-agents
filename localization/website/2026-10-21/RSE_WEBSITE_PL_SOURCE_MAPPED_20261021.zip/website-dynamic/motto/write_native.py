import json,hashlib
from pathlib import Path
b=Path('/workspace/scratch/e6eabdc4c3a0/website-dynamic/motto')
s='''Nie musisz być bez skazy, żeby mieć swoją wartość.
Godności nie dostaje się za dobre zachowanie. Masz ją od urodzenia.
W naszym domu jest miejsce na każde uczucie.
Także wtedy, gdy jest głośno, smutno albo wszystko się miesza.
Słuchamy, żeby zrozumieć. Nie wszystko trzeba od razu naprawiać.
Czasem serce potrzebuje po prostu kogoś, kto wysłucha.
Żaden błąd nie jest większy od naszej miłości.
Gdy coś nie wyjdzie, wciąż masz nas. Jak siatkę, która łapie po upadku.
Uczymy się, oduczamy i rośniemy dalej.
Po drodze może być trochę bałaganu. Zmiana rzadko idzie równym krokiem.
Na odpoczynek nie trzeba zasłużyć.
Nie musimy być bez przerwy zajęci. Pauza też jest potrzebna.
Do siebie też mówimy życzliwie.
Głos w głowie towarzyszy nam długo. Warto ćwiczyć w nim trochę czułości.
Możemy się nie zgadzać i nadal grać w jednej drużynie.
Spór nie musi zrywać tego, co nas łączy.
Łagodność też wymaga odwagi.
Pokazać, że coś nas porusza, to czasem naprawdę odważny krok.
Wolimy być blisko niż wygrać każdą kłótnię.
Chwila, w której się słyszymy, może być cenniejsza od ostatniego słowa.
Zwolnijmy. Odetchnijmy głęboko. Kochajmy mocno.
Świat potrafi pędzić. My możemy na chwilę wybrać inne tempo.
Świętujemy kroki naprzód, nawet te niedoskonałe.
Mały krok też jest powodem do radości.
Twoje granice mają znaczenie.
W domu zaczynamy uczyć się zgody, odmowy i szacunku do siebie.
Sami ustalamy, co dla nas znaczy sukces.
Nie musimy dopasowywać życia do cudzej listy osiągnięć.
Życzliwość to nasz pierwszy rodzinny język.
Zanim pokażemy, jacy jesteśmy błyskotliwi, spróbujmy być dobrzy dla siebie.
Jesteśmy dla siebie. Zostawiamy sobie przestrzeń.
Czasem najcenniejszym podarunkiem jest czyjaś obecność.
Doceniamy drobiazgi, z których składa się dzień.
Zwyczajny wtorek też może dać nam powód do radości.
Zajmujemy się problemem, nie atakujemy człowieka.
Można zmienić zachowanie, nie przekreślając osoby.
Najpierw ciekawość, potem ocena.
Zanim pomyślimy najgorzej, zapytajmy, co się stało.
W zgiełku szukamy spokoju razem.
Dom może być schronieniem, gdy na zewnątrz jest za głośno.
Na łzy też jest u nas miejsce.
Smutku nie trzeba chować. Płacz może być sposobem, by go wyrazić.
Możemy zacząć jeszcze raz.
Poranek przynosi nową kartkę. Nie musi na niej być ciągu dalszego wczorajszej pomyłki.
Słuchamy także własnego głosu.
Uczymy się rozpoznawać intuicję i coraz lepiej ufać sobie.
Mówmy swoją prawdę stanowczo. Kochajmy łagodnie. Rozwijajmy się swobodnie.
Można mieć siłę, czułość i odwagę bycia sobą jednocześnie.
Nasza historia należy do nas.
Mamy wpływ na to, jak ją opowiadamy i co dopiszemy dalej.
Tu można upaść i znów szykować się do lotu.
Miłość zostaje także po porażce. Z takim oparciem łatwiej próbować ponownie.
Głębokie korzenie, szeroko rozłożone skrzydła.
Poczucie przynależności daje oparcie, z którego można ruszać po swojemu.
Po pomyłce można się podnieść.
Błąd nie musi być końcem opowieści. Może pokazać, czego spróbować następnym razem.
Jesteśmy dla siebie portem i wiatrem w żagle.
W domu można odpocząć, a potem nabrać ochoty na dalsze odkrycia.
Budujemy na miłości. Dalej niesie nas wytrwałość.
Ciepło daje oparcie, a wytrwałość pomaga zrobić kolejny krok.
Przetrwajmy burzę. A jeśli się da, zatańczmy w deszczu.
Także w trudnym czasie może znaleźć się miejsce na radość i nowe możliwości.
Podnosimy się razem, małymi odważnymi krokami.
Wspólna droga składa się z drobnych działań. Każde może nas przybliżyć do celu.
Wielkie marzenia mogą startować z domu.
Rodzinne wsparcie bywa pierwszym krokiem do ambitnych planów.
Pomagamy sobie rosnąć.
Własne osiągnięcia często mają w tle kogoś, kto podał rękę.
Odwaga jest naszym kompasem.
Może pomóc wybrać kierunek. Drogę nadal sprawdzamy krok po kroku.
Każde dziecko ma swój blask. Pomagamy go dostrzec.
Zauważamy naturalne możliwości każdego dziecka i dajemy im miejsce.
Każda iskra jest inna. Razem tworzymy ogień.
Nie musimy być tacy sami, żeby tworzyć jedną rodzinę.
Wybieramy prawdziwość, nie nieskazitelność.
Charakter i szczerość są dla nas ważniejsze niż idealny obrazek.
Świecąc po swojemu, pomagamy błyszczeć innym.
Prowadzić innych to także dawać im przestrzeń do własnego działania.
Jesteśmy sobą jako rodzina. Każde z nas jest też osobnym człowiekiem.
Nasze „my” ma miejsce na każde „ja”. Bez potrzeby tłumaczenia się z tego.
W zwykłych chwilach szukamy odrobiny magii.
Codzienny rytm też daje powody do zachwytu i wdzięczności.
Każdy talent może znaleźć swój głos.
Próbuj, twórz i mów odważnie to, co jest twoją prawdą.
Nasz blask zaczyna się w środku.
Pewność siebie może wyrastać z charakteru i zaufania do siebie, nie tylko z cudzych pochwał.
Razem możemy się wyróżniać.
Nie musimy wtapiać się w tło. Wierność swoim wartościom i odmienność też mają siłę.
Dbamy o to, co rozpala nas od środka.
Dajemy czas pasjom i talentom, przy których czujemy, że żyjemy.
Każde z nas rośnie po swojemu. Wciąż jesteśmy blisko.
Rozwój jednej osoby może wzmacniać to, co łączy całą rodzinę.
Zmiana zaczyna się od serca i dociera do kolejnego.
Empatia i więź mogą otwierać drogę do zmiany między ludźmi.
Każde z nas jest dziełem, które wciąż powstaje.
Nie ma ostatniego pociągnięcia pędzlem. Możemy rozwijać się dalej.
Dajemy miejsce na ten etap, gdy wszystko jest jeszcze w rozsypce.
Rozwój nie biegnie po prostej. Wysiłek liczy się także wtedy, gdy trudno zobaczyć, dokąd prowadzi.
Małe kroki potrafią przynieść dużą zmianę.
Wracamy do prób i zauważamy postęp, który przychodzi po trochu.
Tworzymy sobie nawzajem ziemię do wzrastania.
Staramy się budować dom, w którym każdy może rozkwitać na swój sposób.
Uczymy się lubić drogę, nie tylko metę.
To, czego doświadczamy i czego się uczymy, jest równie ważne jak końcowy cel.
Z wczorajszych lekcji budujemy jutrzejszą zmianę.
Dawne doświadczenia mogą dawać nam paliwo do dalszego rozwoju.
Wciąż się uczymy. Wciąż się zmieniamy.
Rozwój nie kończy się w określonym wieku. Ta podróż pozostaje otwarta.
Rise.Shine.Evolve. I od nowa.
Zauważaj, wybieraj, działaj. Do takiego uważnego życia możemy wracać każdego dnia.
Miłość
Empatia
Życzliwość
Odwaga
Zaufanie
Prawda
Wyrozumiałość
Wolność
Spokój
Radość
Szacunek
Rozwój
Nadzieja
Siła
Równowaga
Cierpliwość
Wdzięczność
Uczciwość
Współczucie
Przebaczenie
Otwartość na własną wrażliwość
Nasza kotwica: {v1}. Nasze skrzydła: {v2}.
Początek naszej rodziny to spotkanie dwóch ważnych spraw: {v1} oraz {v2}.
To ćwiczymy łagodnie: {v1}. A to odważnie: {v2}.
Gdy świat hałasuje, przypominamy sobie, co dla nas ważne: {v1} oraz {v2}.
To mówi, kim jesteśmy: {v1}. To buduje naszą więź: {v2}.
Nasz kompas: {v1}. Kierunek, który wskazuje: {v2}.
Nasze korzenie: {v1}. To, ku czemu sięgamy: {v2}.
To chronimy: {v1}. Dzięki temu możemy dawać innym coś równie ważnego: {v2}.
To niesiemy z przeszłości: {v1}. Tak widzimy przyszłość: {v2}.
Najpierw nasz wybór: {v1}. Potem nasze odkrycie: {v2}.
Tu szukamy otuchy: {v1}. Tu wskazówki na dalszą drogę: {v2}.
To nas łączy: {v1}. To daje nam wolność: {v2}.
Nasz fundament: {v1}. Nasz horyzont: {v2}.
To zostaje z nami: {v1}. W tę stronę chcemy się rozwijać: {v2}.'''
p={f'motto.{i:04}':t for i,t in enumerate(s.split('\n'),1)}
assert len(p)==145
for i in range(132,146):assert p[f'motto.{i:04}'].count('{v1}')==p[f'motto.{i:04}'].count('{v2}')==1
(b/'native-proposals.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
notes=[{'ids':['motto.0041','motto.0042'],'reason':'Metaforę dosłownego usuwania uczuć z ciała zastąpiono miejscem na płacz i wyrażeniem smutku, bez obietnicy zdrowotnej.'},{'id':'motto.0070','reason':'Nie zachowano gwarancji zawsze właściwego kierunku dzięki odwadze. Ujęto ją jako możliwą pomoc, z dalszym sprawdzaniem drogi.'},{'id':'motto.0102','reason':'Źródłowy ideał doskonałego środowiska zastąpiono rodzinnym staraniem o warunki rozwoju.'},{'id':'motto.0142','reason':'Uzdrawianie zastąpiono szukaniem otuchy, by nie obiecywać działania terapeutycznego.'},{'id':'motto.0117','reason':'Wybrano Wyrozumiałość zgodnie z briefem: relacyjna łagodność, bez sensu łaski religijnej lub protekcjonalności.'}]
(b/'change-notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n')
print(len(p),hashlib.sha256((b/'native-proposals.json').read_bytes()).hexdigest())
