from pathlib import Path
import re,json,hashlib,subprocess
ROOT=Path('website-source');OUT=Path('website-dynamic')
# A lexical scanner, never app execution. Offsets address the exact original JS literal.
def literals(s,a=0,b=None):
 b=len(s) if b is None else b;i=a
 while i<b:
  if s.startswith('//',i):
   j=s.find('\n',i+2);i=b if j<0 else j+1;continue
  if s.startswith('/*',i):
   j=s.find('*/',i+2);i=b if j<0 else j+2;continue
  if s[i] not in "'\"`":i+=1;continue
  start=i;q=s[i];i+=1
  while i<b:
   if s[i]=='\\':i+=2;continue
   if s[i]==q:i+=1;break
   i+=1
  raw=s[start:i]
  yield start,i,q,raw

def named_range(s,name):
 m=re.search(r'\b(?:const|var|let)\s+'+re.escape(name)+r'\s*=\s*([\[{])',s)
 if not m:return None
 start=m.end()-1;quote_ranges={a:b for a,b,_,_ in literals(s,start)};stack=[];i=start
 while i<len(s):
  if i in quote_ranges:i=quote_ranges[i];continue
  c=s[i]
  if c in '[{':stack.append(c)
  elif c in ']}':
   stack.pop()
   if not stack:return start,i+1
  i+=1
 raise ValueError(name)

allraw=[]
files=['index.html','adventure-app/index.html','unstoppable-app/index.html']
for path in files:
 s=(ROOT/path).read_text();ranges=[]
 for name in ['calmPractices','energyPractices','challenges','characterProfiles','legalCopy']:
  r=named_range(s,name)
  if r:ranges.append((r[0],r[1],name))
 script_ranges=[(m.start(1),m.end(1)) for m in re.finditer(r'<script\b[^>]*>([\s\S]*?)</script\s*>',s,re.I)]
 for a,b,q,raw in [lit for st,en in script_ranges for lit in literals(s,st,en)]:
  scope=next((name for st,en,name in ranges if st<=a<en),None)
  # Property detection is semantic allowlist; array description/qualities inherited by last field.
  prior=s[max(0,a-1000):a]
  keym=re.search(r'(\w+)\s*:\s*$',prior)
  key=keym.group(1) if keym else None
  if scope:
   if key in ['title','instruction','comment','tagline','body']:
    kind=key
   elif scope=='characterProfiles' and re.search(r'(?:description|qualities)\s*:\s*\[[^\]]*$',prior,re.S):
    kind='description' if re.search(r'description\s*:\s*\[[^\]]*$',prior,re.S) else 'quality'
   else:continue
  else:
   # Only explicit UI sinks. Avoid implementation strings, URLs, IDs, classes, object keys and selectors.
   prior=s[max(0,a-250):a]
   if not re.search(r'(?:textContent|innerText|innerHTML)\s*(?:\+?=)|\b(?:alert|confirm|prompt)\s*\([^)]*$',prior,re.S):continue
   if re.search(r'[;{}]',prior.split('\n')[-1]) and not re.search(r'(?:textContent|innerText|innerHTML)\s*\+?=\s*$',prior):continue
   kind='ui'
  if '${' in raw:kind+='-template'
  allraw.append({'page':path,'start':a,'end':b,'quote':q,'raw':raw,'field':kind,'scope':scope})
# Decode JS literal in a context with no host APIs. Only already lexed literals.
# Template interpolations are not evaluated and become explicit unresolved items.
plain=[x for x in allraw if '${' not in x['raw']]
proc=subprocess.run(['node','-e',"const fs=require('fs'),vm=require('vm');const rows=JSON.parse(fs.readFileSync(0,'utf8'));console.log(JSON.stringify(rows.map(x=>vm.runInNewContext('('+x+')',Object.create(null),{timeout:100}))));"],input=json.dumps([x['raw'] for x in plain]),text=True,capture_output=True)
if proc.returncode:raise ValueError(proc.stderr)
values=json.loads(proc.stdout)
static=json.loads(Path('website-work/analysis-units.json').read_text());static_values={x['text'] for x in static}
rows=[];occ=[];by={};excluded=[]
for item,value in zip(plain,values):
 if not isinstance(value,str) or not re.search('[A-Za-z]',value):continue
 if value in static_values:excluded.append({**item,'reason':'exact static source string','value':value});continue
 if len(value.strip())<3:continue
 key=value
 if key not in by:
  sid=f'dynamic.{len(rows)+1:04d}';by[key]=sid
  rows.append({'id':sid,'text':value,'kind':item['field'],'scope':item['scope'],'first_page':item['page'],'source_ref':f"{item['page']}:{item['start']}-{item['end']}"})
 occ.append({**item,'value':value,'id':by[key]})
OUT.joinpath('analysis-units.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
OUT.joinpath('source.json').write_text(json.dumps({'language':'en','segments':[{'id':x['id'],'text':x['text']} for x in rows]},ensure_ascii=False,indent=2)+'\n')
OUT.joinpath('occurrences.json').write_text(json.dumps(occ,ensure_ascii=False,indent=2)+'\n')
OUT.joinpath('static-duplicates.json').write_text(json.dumps(excluded,ensure_ascii=False,indent=2)+'\n')
OUT.joinpath('unresolved-templates.json').write_text(json.dumps([x for x in allraw if '${' in x['raw']],ensure_ascii=False,indent=2)+'\n')
OUT.joinpath('source-lock.json').write_text(json.dumps({'files':{p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in files},'method':'lexical literal spans; named-data field allowlist; explicit UI sinks; no app execution','not_captured':['Expressions containing template interpolations are quarantined','Arbitrary dynamically constructed UI/HTML not selected by literal sink heuristic requires source review','External data/rse-format-options.json not available locally at extraction']},indent=2)+'\n')
print({'unique':len(rows),'occurrences':len(occ),'chars':sum(len(x['text']) for x in rows),'duplicates_of_static':len(excluded),'unresolved_templates':len([x for x in allraw if '${' in x['raw']])})
