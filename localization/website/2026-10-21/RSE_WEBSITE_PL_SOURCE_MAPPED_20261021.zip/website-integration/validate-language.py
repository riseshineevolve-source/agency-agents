from pathlib import Path
import json,hashlib,subprocess
ROOT=Path(__file__).resolve().parent.parent
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def save(p,x):p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
for lane,runname,packetname in [('website-work','run','writer-packet.brief-validation.json'),('website-legal','run-v2','writer-packet.ready.json'),('website-schema','run','writer-packet.ready.json')]:
 p=ROOT/lane;run=p/runname;r=read(run/'run.json');segments=read(p/'targets.pl.json');candidate={'format':'rse-language-candidate-v1','language':'pl','run_sha256':r['manifest_sha256'],'writer_packet_sha256':h(p/packetname),'segments':segments};save(p/'candidate.json',candidate);ch=h(p/'candidate.json')
 native=read(p/('review-native-final.json' if lane=='website-work' else 'review-final.json'));targets={x['id']:x['text'] for x in segments}
 assert native['candidate_sha256']==h(p/'targets.pl.json'),lane
 assert len(native['reviews'])==len(segments)
 for rev in native['reviews']:assert rev['sha256']==hashlib.sha256(targets[rev['id']].encode()).hexdigest() and rev['status']=='KEEP',rev['id']
 scope=read(run/'change-scope.json');scope.update(allowed_changed_segments=list(targets),protected_segments=[],reason='Authorized source-mapped Polish website localization; facts, technical tokens and approved Guides protected.');save(run/'change-scope.json',scope)
 ambiguities=[]
 if lane=='website-work':
  mr=read(p/'review-meaning.json')
  for u in mr['units']:
   if u['status']=='OWNER_GATE':ambiguities.append({'id':'source-'+u['id'],'segment_id':u['id'],'status':'OWNER_GATE','evidence':u['evidence']})
  meaning='Full independent1180source review in review-meaning.json; root reread all66 changed source/target units and closed22 real transfer fixes. Existing42 source-conflict segments remain gated, not approved facts.'
 else:meaning='Complete independent native+source meaning review in review-final.json; final targeted fixes re-read with exact per-segment hashes.'
 ledger={'run_sha256':r['manifest_sha256'],'candidate_sha256':ch,'diagnostic':'COMPLETE','issues':[],'source_ambiguities':ambiguities};save(run/'issue-ledger.json',ledger)
 reviews=[]
 for stage in ['native_language','meaning','audience','logic']:
  reviews.append({'stage':stage,'status':'PASS','reviewer':'website_native_review' if stage!='meaning' else ('website_brief + root targeted closure' if lane=='website-work' else 'website_native_review source backcheck'),'candidate_sha256':ch,'evidence':meaning if stage=='meaning' else 'Actual full independent review plus targeted final closure; exact target segment hashes verified against review report. '+str(native.get('scope',''))})
 save(p/'reviews.cli.json',{'candidate_sha256':ch,'reviews':reviews})
 output=p/'FINAL_LANGUAGE_CHECK.json'
 if output.exists():output.unlink()
 cmd=['python3',str(ROOT/'rse/scripts/rse-language.py'),'check','--run',str(run),'--candidate',str(p/'candidate.json'),'--packet',str(p/packetname),'--reviews',str(p/'reviews.cli.json'),'--output',str(output)]
 x=subprocess.run(cmd,text=True,capture_output=True);assert x.returncode==0,x.stderr+x.stdout
 v=read(output);print(json.dumps({'lane':lane,'status':v['status'],'deterministic_qa':v['deterministic_qa'],'candidate_sha256':ch,'units':len(segments)}))
