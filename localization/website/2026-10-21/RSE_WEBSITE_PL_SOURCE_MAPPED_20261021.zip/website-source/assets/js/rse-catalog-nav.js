// Native buttons keep the existing home section and Gifts access behavior.
(function () {
  const tabs = document.querySelector('.tabs');
  if (!tabs) return;
  function syncPressedState() {
    tabs.querySelectorAll('button[data-tab]').forEach(function (button) {
      button.setAttribute('aria-pressed', String(button.classList.contains('active')));
    });
  }
  syncPressedState();
  new MutationObserver(syncPressedState).observe(tabs, {
    subtree: true, attributes: true, attributeFilter: ['class']
  });
})();
