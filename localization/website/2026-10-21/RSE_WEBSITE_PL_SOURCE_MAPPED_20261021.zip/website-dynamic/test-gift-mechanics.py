from pathlib import Path
import json,re,subprocess,hashlib
R=Path(__file__).resolve().parent
s=(R/'final-proposed-source/index.html').read_text();rows=json.loads((R/'wordhunt/candidate.json').read_text())['segments'];banks=[]
for i in range(0,len(rows),13):
 words=[x['text'] for x in rows[i+1:i+13]]
 assert len(words)==len(set(words))==12
 assert all(0<len(w)<=12 and w==w.upper() and all(c.isalpha() and ord(c)<65536 for c in w) for w in words)
 banks.append(words)
# Execute only source-defined pure placement functions in isolatedJS, no app/network/browser/auth.
a=s.index('    function createEmptyGrid(size)');b=s.index('    function renderGrid()',a);functions=s[a:b]
js="""let seed=1;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};const gridSize=12,alphabet='AĄBCĆDEĘFGHIJKLŁMNŃOÓPQRSŚTUUVWXYZŹŻ',directions=[[0,1],[1,0],[0,-1],[-1,0],[1,1],[-1,-1],[1,-1],[-1,1]];let failures=0,missing=[];console.warn=()=>{};
"""+functions+"\nconst banks="+json.dumps(banks,ensure_ascii=False)+""";
function exists(g,w){for(let r=0;r<12;r++)for(let c=0;c<12;c++)for(const [dr,dc] of directions){if([...w].every((ch,i)=>g[r+dr*i]?.[c+dc*i]===ch))return true;}return false;}
for(let n=1;n<=500;n++){for(const bank of banks){seed=n;let g=buildGrid(bank);for(const w of bank){if(!exists(g,w)){failures++;missing.push({seed:n,word:w});}}}}const oldAttempt=buildGridAttempt;buildGridAttempt=()=>createEmptyGrid(12);const forcedFallback=buildGrid(banks[0]);const forcedFallbackPass=banks[0].every(w=>exists(forcedFallback,w));buildGridAttempt=oldAttempt;let invalidRejected=false;try{buildGrid(['ABCDEFGHIJKLM'])}catch(e){invalidRejected=true;}console.log(JSON.stringify({grids:2500,wordAssertions:30000,failures,missing,forcedFallbackPass,invalidRejected}));
"""
x=subprocess.run(['node','-e',js],capture_output=True,text=True,check=True);result=json.loads(x.stdout)
# Language-isolation check on actual proposed source; only state-key literal inspected, no user storage read.
p=(R/'final-proposed-source/index.html').read_text();result['stateKeys']={key:bool(re.search(r"const "+key+r" = [\"']"+value+r":pl[\"']",p)) for key,value in [('CALM_ENERGY_STATE_KEY','hmCalmEnergyState'),('ONE_MINUTE_STATE_KEY','hmOneMinuteState'),('WORD_HUNT_STATE_KEY','hmWordHuntState')]}
result['scope']='2500 deterministic source-algorithm trials; not guarantee of stochastic placement or browser UI';result['alphabet_contains_polish']=all(c in p for c in 'ĄĆĘŁŃÓŚŹŻ')
(R/'GIFT_MECHANICS_QA.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
