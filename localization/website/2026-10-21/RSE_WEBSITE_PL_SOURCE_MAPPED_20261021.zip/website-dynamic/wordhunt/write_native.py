import json,hashlib
from pathlib import Path
b=Path('/workspace/scratch/e6eabdc4c3a0/website-dynamic/wordhunt')
s='''Wykreślanka Happy Makers
RISE
SHINE
EVOLVE
ZŁOTO
FIOLET
ISKRA
JASNOŚĆ
ENERGIA
SPOKÓJ
RADOŚĆ
POŚWIATA
PREZENT
Rodzinna ekipa Happy Makers
MIMI
LULI
DILO
ALIO
NINI
BIBI
MAMA
TATA
RODZINA
DRUŻYNA
MIŁOŚĆ
UŚMIECH
Magia tworzenia
SZCZĘŚCIE
MAKERS
MAGIA
ZABAWA
TWORZENIE
KOLOR
ŚMIECH
SERCE
ODWAGA
ŚMIAŁOŚĆ
ŻYCZLIWOŚĆ
ZAPAŁ
Iskry przygody
PODRÓŻE
ZAGADKA
MISJA
PRACOWNIA
POMYSŁY
SŁOWA
BOHATEROWIE
GWIAZDY
KSIĘŻYC
SŁOŃCE
MARZENIE
POŚWIATA
Świętujemy razem
KONFETTI
ŚWIĘTOWANIE
ZWYCIĘZCA
PREZENT
MUZYKA
TANIEC
HOJNOŚĆ
SHINE
HURRA
MIGOTANIE
SZCZĘŚCIE
ZŁOTO'''
p={f'wordhunt.{i:04}':v for i,v in enumerate(s.split('\n'),1)}
assert len(p)==65
for start in range(1,66,13):
 words=[p[f'wordhunt.{i:04}'] for i in range(start+1,start+13)]
 assert len(set(words))==12
 for w in words:assert 1<=len(w)<=12 and w.isupper() and w.isalpha() and all(ord(c)<=65535 for c in w),w
(b/'native-proposals.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
(b/'change-notes.json').write_text(json.dumps([{'id':'wordhunt.0060','reason':'Zastosowano HOJNOŚĆ jako naturalne jednowyrazowe hasło rodziny znaczeniowej dzielenia się. Forma DZIELENIE bez się oznaczałaby także działanie matematyczne; sztuczne sklejenie słów odrzucono.'}],ensure_ascii=False,indent=2)+'\n')
print(len(p),hashlib.sha256((b/'native-proposals.json').read_bytes()).hexdigest())
