# Native Polish dynamic website supplement

Status: LOCAL_PREVIEW_CANDIDATE. No source English edit, remote publication, merge or production freeze occurred.

## Integration contract

1. Import `compile.py`; call `build_maps(main_dynamic_candidate, static_candidate)`.
2. Call `apply_to_file(relative_path, FROZEN_ENGLISH_TEXT, dynamic_map, static_map)` before static DOM localization. It merges exact offsets for main dynamic literals, Motto and Word Hunt in one pass; applying another offset patch to modified HTML is invalid.
3. Apply `apply_json()` to the format catalog. It preserves IDs, merchant URLs and state values; rebinds editorial routes to `/pl/assets/content/`.
4. After assembling output root call `finalize_preview(output_root)`. It writes **only** `output_root/pl/assets/word-search-studio/inline.js`. Rewire Polish script references to this PL asset; preserve English asset/reference.
5. Keep localized shared hub runtime and catalog under `/pl/`; emit four localized editorial assets from translated canonical detail pages as previously agreed. No fallback to English editorial text should be silently accepted.

`integration-proof/` demonstrates dynamic compilation against frozen English before static DOM rewriting; it is not the complete static Polish website. It includes the three accepted Polish cover-image alt attributes. `DYNAMIC_SOURCE_FILES.json` checks all five original inputs exactly, including the hydrated catalog bytes.

## Content and evidence

- `candidate.json`: 551 units = 502 native reader-facing units and 49 unchanged implementation literals. Final source/target and independent review: `independent-review.json`, `independent-review-final.json`, `independent-review-final2.json`.
- `motto/candidate.json`: 145 units, including all 55 motto/hint pairs, 21 values and 14 templates. Each template has two preserved placeholders and one deliberate line break. `motto/independent-review-final.json` accepts the final bounded boundary-respect correction.
- `wordhunt/candidate.json`: 65 units, five titles plus five banks of 12 targets. Independent language/meaning review accepted exact character/brand locks and bounded theme adaptations.
- `studio/candidate.json` and `studio/targets.pl.json`: 53 units covering 77 exact reader-facing occurrences, all UI/errors/print/win labels and five actual Polish word banks. `studio/review-meaning.json` accepts all 53. Its target-list hash is separately verified identical to the engine candidate's ordered ID/text payload.
- Every run has a validated source-free writer packet, packet receipt, exact source, functional brief, candidate, scope, current issue ledger and `current-check.json`. The initial native writer did not see source prose; source was opened only for targeted backcheck.
- Current engine deterministic checks pass for every run. Gift datasets have real review receipts. Main run remains OWNER_GATE; engine specialist acceptance is not asserted over unresolved source safety/legal/status facts. Actual independent main reviews are provided separately.

## Necessary locale runtime changes

- All three homepage game/session state keys gain `:pl`, preventing an earlier English cached result or grid from overwriting Polish content. Authentication/user account keys remain untouched.
- Both word-search fillers include Polish diacritics.
- Homepage Word Hunt retains its 12×12 grid, word counts and directions. Atomic generation retries eight times and validates every target. A bounded deterministic horizontal-row fallback preserves all listed words instead of publishing an impossible grid.
- Studio transport uses a JSON string assignment to the same `window.WORD_SEARCH_STUDIO_HTML` API. This preserves nested JS/HTML escapes. Corrected the source decoding defect `split(/s+/)` to whitespace `split(/\s+/)`.
- Correct Polish ninety, `dziewięćdziesiąt`, has 16 Unicode code points. Studio PL validation and error text therefore allow 16 letters. Initial capacity is 16, bounded growth reaches 35, and full-grid attempts reach 32; the original shapes, difficulty directions, spacing, 5–12 word limit and visible failure branch remain.
- Three source-backed native Polish image alternatives are applied only to their exact cover alt values, retaining English book titles, URLs and all other markup.

## Verification

- `JS_SYNTAX_QA_FINAL.json`: 14 source/compiled-script syntax checks, all pass, including the outer Studio transport and decoded scripts. No full app, network or authentication script was executed.
- `GIFT_MECHANICS_QA_SOURCE_DEFECT.json`: original Word Hunt algorithm produced 9 missing target instances in 2,500 seeded grids.
- `GIFT_MECHANICS_QA.json`: corrected generation, 2,500 grids and 30,000 target assertions, zero missing words. Forced retry-exhaustion fallback passes; invalid-length input is rejected. Three state-key locale checks pass.
- `studio/MECHANICS_QA_BEFORE_CAPACITY.json`: source 25-cell capacity failed to generate 44 of 225 Polish preset trials; no impossible partial grid rendered.
- `studio/MECHANICS_QA.json`: 225 preset plus 45 custom long-word trials across five shapes, three difficulties and three seeds. Zero generation failures and zero unfindable targets. Actual failure-path stub confirms 32-attempt exhaustion shows Polish failure UI and never renders a partial grid; 17-letter input is rejected. Five whitespace-delimited custom words parse correctly. Transport round trip is byte exact; state is language-isolated.

These are deterministic and pure-method checks, with minimal DOM stubs only for failure/validation branches. Real browser interaction, authentication, email delivery, mobile grid fit, downloads/PDF print fit and rendered accessibility are not claimed here. Capacity 35 may require a visual fit check at small viewport widths.

## Unresolved source/publication gates

1. Main Nini portrait says age 4, World 01 panel says age 5. Preserve the contradictory original facts until source authority resolves them.
2. Source 3–3–3–3 breathing activity contains two breath holds. Language fidelity does not establish universal suitability; preserve the source safety gate.
3. Source privacy policy asserts password encryption, retention, cross-border safeguards and GDPR/RODO/CCPA compliance. Conservative translation preserves those source claims, including jurisdictions; factual/legal verification is still required.
4. Google Play coming-soon wording coexists with an explicit absence of a listing. Do not convert that into a verified listing, release date, purchase availability or paid access.

Owner-locked Gentle Steps title/subtitle/daily labels override obsolete PL packaging narrowly. Other product English-edition titles remain proper names. `Gifts` is consistently `Darmowe materiały` in accepted reader-facing copy. English source, source book mechanics, merchant links and product availability were not invented.
