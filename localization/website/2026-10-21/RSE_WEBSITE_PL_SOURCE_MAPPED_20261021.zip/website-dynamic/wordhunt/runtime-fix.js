    // Locale dependency closure: never offer a grid missing a listed target.
    function wordHuntContains(grid, word) {
      for (let row = 0; row < gridSize; row++) {
        for (let col = 0; col < gridSize; col++) {
          for (const [dr, dc] of directions) {
            if (Array.from(word).every((letter, i) => grid[row + dr * i]?.[col + dc * i] === letter)) return true;
          }
        }
      }
      return false;
    }

    function buildGrid(wordList) {
      if (!Array.isArray(wordList) || wordList.length > gridSize || wordList.some(word => !word || Array.from(word).length > gridSize)) {
        throw new Error('Nie można utworzyć wykreślanki z podanych słów.');
      }
      for (let retry = 0; retry < 8; retry++) {
        const candidate = buildGridAttempt(wordList);
        if (wordList.every(word => wordHuntContains(candidate, word))) return candidate;
      }
      // A bounded fallback keeps all target words and the same 12×12 rules.
      const fallback = createEmptyGrid(gridSize);
      wordList.forEach((word, row) => Array.from(word).forEach((letter, col) => { fallback[row][col] = letter; }));
      for (let row = 0; row < gridSize; row++) {
        for (let col = 0; col < gridSize; col++) {
          if (fallback[row][col] === '.') fallback[row][col] = alphabet[Math.floor(Math.random() * alphabet.length)];
        }
      }
      if (!wordList.every(word => wordHuntContains(fallback, word))) throw new Error('Nie udało się utworzyć pełnej wykreślanki.');
      return fallback;
    }

