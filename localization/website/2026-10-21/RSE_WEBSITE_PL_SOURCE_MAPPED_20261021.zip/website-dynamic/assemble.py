from pathlib import Path
import json,re,hashlib
R=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
s=read(R/'source.json');p=read(R/'native-proposals.json');tags=read(R/'html-tag-token-maps.json')
expected={x['id'] for x in s['segments'] if not x.get('protected')}
assert set(p)==expected,(expected-set(p),set(p)-expected)
for u in s['segments']:
 sid=u['id'];v=u['text'] if u.get('protected') else p[sid]
 if sid in tags:
  layout=read(R/'functional-brief.layout-tokens.json')['units'][int(sid.split('.')[1])-1]['mechanics']['html_token_layout']
  assert re.findall(r'\{tag_\d+\}',layout)==re.findall(r'\{tag_\d+\}',v),sid
  assert not re.search(r'\{copy_\d+\}',v),sid
  v=re.sub(r'\{tag_\d+\}',lambda m:tags[sid][m[0]],v)
  assert re.findall(r'<[^>]+>',u['text'])==re.findall(r'<[^>]+>',v),sid
 for t in u.get('protected_tokens',[]):assert v.count(t)==u['text'].count(t),(sid,t)
 u['text']=v
s['format']='rse-language-candidate-v1';s['run_sha256']=read(R/'run/run.json')['manifest_sha256'];s['language']='pl';s['writer_packet_sha256']=hashlib.sha256((R/'writer-packet.layout-tokens.json').read_bytes()).hexdigest()
(R/'candidate.json').write_text(json.dumps(s,ensure_ascii=False,indent=2)+'\n')
print('candidate',len(s['segments']),hashlib.sha256((R/'candidate.json').read_bytes()).hexdigest())
