from pathlib import Path
import json,re,subprocess
R=Path(__file__).resolve().parent;s=(R/'proposed.html').read_text();a=s.index('        class WordSearchGenerator {');b=s.index('        // Inicjalizuj generator',a);cls=s[a:b];assert 'static ' not in cls
rows=json.loads((R/'targets.pl.json').read_text());banks=[x['text'].upper().split() for x in rows if int(x['id'].split('.')[1])>=49];assert [len(x) for x in banks]==[12,7,11,9,9];assert max(map(len,sum(banks,[])))==16
js="let seed=1;Math.random=()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296};\n"+cls+"\nconst banks="+json.dumps(banks,ensure_ascii=False)+""";
banks.push(['DZIEWIĘĆDZIESIĄT','PONIEDZIAŁEK','PAŹDZIERNIK','WRZESIEŃ','SZCZĘŚCIE']);let runs=0,failed=[],bad=[];const dirs={easy:[[0,1],[1,0]],medium:[[0,1],[1,0],[1,1],[-1,1]],hard:[[0,1],[1,0],[1,1],[-1,1],[0,-1],[-1,0],[-1,-1],[1,-1]]};
for(let n=1;n<=3;n++)for(let bank=0;bank<banks.length;bank++)for(const shape of ['square','circle','hexagon','diamond','heart'])for(const difficulty of ['easy','medium','hard']){
 seed=n;let x=Object.create(WordSearchGenerator.prototype);Object.assign(x,{words:banks[bank],shape,difficulty,randomSeed:n*714,generationId:'az0123456789',directions:dirs});x.calculateGridSize();let success=false,attempts=0;while(attempts<32&&!success){success=x.createGrid();attempts++;if(!success)x.gridSize=Math.min(35,x.gridSize+1);}runs++;
 if(!success){failed.push({n,bank,shape,difficulty,size:x.gridSize});continue;}
 for(const w of x.words){let found=false;for(let r=0;r<x.gridSize;r++)for(let c=0;c<x.gridSize;c++)for(const [dr,dc] of dirs[difficulty]){if([...w].every((ch,i)=>x.grid[r+dr*i]?.[c+dc*i]===ch))found=true;}if(!found)bad.push({w,shape,difficulty});}
}
const splitCheck='kot  pies\\tdom\\nkwiat auto'.toUpperCase().split(/\\s+/).filter(Boolean);let rendered=false,calls=0;const input={value:'kot  pies\\tdom\\nkwiat auto'},preset={value:'custom'},error={innerHTML:''};global.document={getElementById:id=>({words:input,wordPresets:preset,errorMessage:error}[id])};const y=Object.create(WordSearchGenerator.prototype);Object.assign(y,{difficulty:'easy',createGrid:()=>{calls++;return false;},renderGrid:()=>{rendered=true;}});y.generatePuzzle();const maxFailureVisible=error.innerHTML.includes('Nie udało')&&calls===32&&!rendered;input.value='ABCDEFGHIJKLMNOPQ kot pies dom auto';y.generatePuzzle();const tooLongRejected=error.innerHTML.includes('16');console.log(JSON.stringify({runs,visibleGenerationFailures:failed,unfindableTargets:bad,whitespaceWords:splitCheck.length,polish90Codepoints:Array.from('dziewięćdziesiąt').length,maxFailureVisible,tooLongRejected}));
"""
p=subprocess.run(['node','-e',js],capture_output=True,text=True,check=True);v=json.loads(p.stdout);v['scope']='225 preset +45 custom long-word placement runs across5shapes×3difficulties×3seeds; no DOM/network/auth/printing executed';v['session_state_language_isolated']="'hmWordSearchStudioState:pl'" in s
# Validate transport roundtrip preserves every decoded byte, including nested regex and JS templates.
transport=(R/'inline.pl.js').read_text();v['transport_roundtrip_exact']=json.loads(transport.split(' = ',1)[1].rstrip(';\n'))==s
(R/'MECHANICS_QA.json').write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n');print(json.dumps(v,ensure_ascii=False))
