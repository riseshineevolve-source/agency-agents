(function () {
  "use strict";

  var MEASUREMENT_ID = "G-WW6C0S6031";
  var STORAGE_KEY = "rse_analytics_consent_v1";
  var PROD_HOSTS = ["rise-shine-evolve-learning-hub.com", "www.rise-shine-evolve-learning-hub.com"];

  window.dataLayer = window.dataLayer || [];
  window.gtag = window.gtag || function () { window.dataLayer.push(arguments); };

  // Privacy-first Consent Mode v2 defaults. Marketing consent remains denied.
  window.gtag("consent", "default", {
    analytics_storage: "denied",
    ad_storage: "denied",
    ad_user_data: "denied",
    ad_personalization: "denied",
    wait_for_update: 500
  });

  window.gtag("set", "ads_data_redaction", true);
  window.gtag("set", "url_passthrough", false);

  var tagLoaded = false;
  var analyticsGranted = false;

  function isProduction() {
    return PROD_HOSTS.indexOf(window.location.hostname) !== -1;
  }

  function readChoice() {
    try {
      return window.localStorage.getItem(STORAGE_KEY);
    } catch (e) {
      return null;
    }
  }

  function saveChoice(choice) {
    try {
      window.localStorage.setItem(STORAGE_KEY, choice);
    } catch (e) {
      // Consent still applies for the current page even when storage is unavailable.
    }
  }

  function hasGlobalPrivacyControl() {
    return navigator.globalPrivacyControl === true;
  }

  function clearAnalyticsCookies() {
    if (!isProduction()) return;

    var names = document.cookie
      .split(";")
      .map(function (part) { return part.split("=")[0].trim(); })
      .filter(function (name) {
        return name === "_ga" || name.indexOf("_ga_") === 0 || name === "_gid" || name === "_gat";
      });

    var host = window.location.hostname.replace(/^www\./, "");
    names.forEach(function (name) {
      var encoded = encodeURIComponent(name);
      document.cookie = encoded + "=; Max-Age=0; Path=/; SameSite=Lax";
      document.cookie = encoded + "=; Max-Age=0; Path=/; Domain=." + host + "; SameSite=Lax";
    });
  }

  function loadGoogleTag() {
    if (tagLoaded || !isProduction()) return;
    tagLoaded = true;

    var script = document.createElement("script");
    script.async = true;
    script.src = "https://www.googletagmanager.com/gtag/js?id=" + encodeURIComponent(MEASUREMENT_ID);
    document.head.appendChild(script);

    window.gtag("js", new Date());
    window.gtag("config", MEASUREMENT_ID, {
      allow_google_signals: false,
      allow_ad_personalization_signals: false
    });
  }

  function applyAnalyticsConsent(granted, persist) {
    if (hasGlobalPrivacyControl()) granted = false;
    analyticsGranted = granted === true;

    window.gtag("consent", "update", {
      analytics_storage: analyticsGranted ? "granted" : "denied",
      ad_storage: "denied",
      ad_user_data: "denied",
      ad_personalization: "denied"
    });

    if (persist) saveChoice(analyticsGranted ? "granted" : "denied");
    if (analyticsGranted) {
      loadGoogleTag();
    } else {
      clearAnalyticsCookies();
    }
  }

  function removeBanner() {
    var banner = document.getElementById("rse-consent-banner");
    if (banner) banner.remove();
  }

  function ensureManageButton() {
    if (document.getElementById("rse-privacy-choices")) return;

    var button = document.createElement("button");
    button.id = "rse-privacy-choices";
    button.type = "button";
    button.textContent = "Ustawienia prywatności";
    button.setAttribute("aria-label", "Otwórz ustawienia prywatności dotyczące analityki");
    button.style.cssText = [
      "position:fixed",
      "right:12px",
      "bottom:12px",
      "z-index:2147483646",
      "border:1px solid rgba(255,255,255,.32)",
      "border-radius:999px",
      "padding:8px 12px",
      "background:#111827",
      "color:#fff",
      "font:600 12px/1.2 system-ui,-apple-system,Segoe UI,Roboto,sans-serif",
      "box-shadow:0 4px 18px rgba(0,0,0,.28)",
      "cursor:pointer"
    ].join(";");

    button.addEventListener("click", function () {
      showBanner(true);
    });

    document.body.appendChild(button);
  }

  function showBanner(force) {
    if (!isProduction()) return;

    if (!force && readChoice()) {
      ensureManageButton();
      return;
    }

    removeBanner();

    var wrap = document.createElement("div");
    wrap.id = "rse-consent-banner";
    wrap.setAttribute("role", "dialog");
    wrap.setAttribute("aria-modal", "true");
    wrap.setAttribute("aria-labelledby", "rse-consent-title");
    wrap.style.cssText = [
      "position:fixed",
      "left:0",
      "right:0",
      "bottom:0",
      "z-index:2147483647",
      "padding:14px",
      "background:rgba(5,5,10,.97)",
      "color:#fff",
      "border-top:1px solid rgba(255,255,255,.22)",
      "box-shadow:0 -10px 30px rgba(0,0,0,.35)",
      "font:400 14px/1.45 system-ui,-apple-system,Segoe UI,Roboto,sans-serif"
    ].join(";");

    var inner = document.createElement("div");
    inner.style.cssText = "max-width:980px;margin:0 auto;display:grid;gap:12px";

    var title = document.createElement("strong");
    title.id = "rse-consent-title";
    title.textContent = "Prywatność i analityka";

    var copy = document.createElement("div");
    var gpcActive = hasGlobalPrivacyControl();
    var copyText = document.createElement("span");
    copyText.textContent = gpcActive
      ? "W tej przeglądarce jest aktywny sygnał Global Privacy Control, dlatego analityka pozostaje wyłączona. Przechowywanie danych reklamowych i personalizacja reklam również pozostają wyłączone."
      : "Korzystamy z Google Analytics wyłącznie wtedy, gdy zezwolisz na analitykę. Pomaga nam to zrozumieć, które strony i materiały Rise.Shine.Evolve. są przydatne. Przechowywanie danych reklamowych i personalizacja reklam pozostają wyłączone.";
    var privacyLink = document.createElement("a");
    privacyLink.href = "/pl/privacy/";
    privacyLink.textContent = "Polityka prywatności";
    privacyLink.style.cssText = "color:#9ff6ff;text-decoration:underline;font-weight:700";
    copy.appendChild(copyText);
    copy.appendChild(privacyLink);

    var actions = document.createElement("div");
    actions.style.cssText = "display:flex;flex-wrap:wrap;gap:10px";

    function makeButton(label) {
      var button = document.createElement("button");
      button.type = "button";
      button.textContent = label;
      button.style.cssText = [
        "min-height:42px",
        "border:1px solid rgba(255,255,255,.55)",
        "border-radius:999px",
        "padding:9px 16px",
        "background:#111827",
        "color:#fff",
        "font:700 14px/1.2 system-ui,-apple-system,Segoe UI,Roboto,sans-serif",
        "cursor:pointer"
      ].join(";");
      return button;
    }

    var reject = makeButton(gpcActive ? "Zamknij" : "Odrzuć analitykę");
    var accept = gpcActive ? null : makeButton("Zezwól na analitykę");

    reject.addEventListener("click", function () {
      if (!gpcActive) applyAnalyticsConsent(false, true);
      removeBanner();
      ensureManageButton();
    });

    if (accept) {
      accept.addEventListener("click", function () {
        applyAnalyticsConsent(true, true);
        removeBanner();
        ensureManageButton();
      });
    }

    actions.appendChild(reject);
    if (accept) actions.appendChild(accept);
    inner.appendChild(title);
    inner.appendChild(copy);
    inner.appendChild(actions);
    wrap.appendChild(inner);
    document.body.appendChild(wrap);

    window.setTimeout(function () {
      reject.focus();
    }, 0);
  }

  // Small helper for future custom GA4 events. No event is sent without analytics consent.
  window.rseAnalytics = {
    measurementId: MEASUREMENT_ID,
    track: function (eventName, params) {
      if (!analyticsGranted || hasGlobalPrivacyControl()) return false;
      loadGoogleTag();
      window.gtag("event", eventName, params || {});
      return true;
    },
    openPrivacyChoices: function () {
      showBanner(true);
    }
  };

  var choice = readChoice();

  if (hasGlobalPrivacyControl()) {
    applyAnalyticsConsent(false, false);
  } else if (choice === "granted") {
    applyAnalyticsConsent(true, false);
  } else if (choice === "denied") {
    applyAnalyticsConsent(false, false);
  }

  function routeLegacyPrivacyControls() {
    document.addEventListener("click", function (event) {
      var target = event.target && event.target.closest ? event.target.closest('[data-legal="privacy"]') : null;
      if (!target) return;
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
      window.location.href = "/pl/privacy/";
    }, true);
  }

  function initUi() {
    if (!isProduction()) return;

    routeLegacyPrivacyControls();

    if (!choice && !hasGlobalPrivacyControl()) {
      showBanner(false);
    } else {
      ensureManageButton();
    }
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initUi, { once: true });
  } else {
    initUi();
  }
})();
