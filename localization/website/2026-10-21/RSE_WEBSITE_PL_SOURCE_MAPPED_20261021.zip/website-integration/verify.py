#!/usr/bin/env python3
"""Checks real compiled outputs, source structure/styles, references and JS syntax."""
from pathlib import Path
from lxml import html
import json,hashlib,subprocess,tempfile,re,argparse
ROOT=Path(__file__).resolve().parent.parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(out):
 report=json.loads((out/'BUILD_REPORT.json').read_text());errors=[];stats={'pages':0,'style_blocks':0,'inline_js':0,'external_local_js':0,'relative_links':0,'book_language_en':0}
 for page in report['pages']:
  source=html.fromstring((ROOT/'website-source'/page['source']).read_bytes());target=html.fromstring((out/page['target']).read_bytes());stats['pages']+=1
  assert [n.tag for n in source.iter() if isinstance(n.tag,str)]==[n.tag for n in target.iter() if isinstance(n.tag,str)],page['source']
  assert source.xpath('//style/text()')==target.xpath('//style/text()'),('CSS changed',page['source']);stats['style_blocks']+=len(target.xpath('//style'))
  assert source.xpath('//@style')==target.xpath('//@style'),('inline styles changed',page['source'])
  assert target.get('lang')=='pl';assert target.xpath('//meta[@name="robots" and contains(@content,"noindex")]'),page['source']
  assert not re.search(r'\{(?:slot_\d+|tag_\d+|copy_\d+)\}',(out/page['target']).read_text()),page['source']
  for a in target.xpath('//*[@href or @src]'):
   for attr in ['href','src']:
    link=a.get(attr,'')
    if not link or link.startswith(('http:','https:','//','mailto:','tel:','data:','javascript:','#','/')):continue
    path=(out/page['target']).parent/link.split('#')[0].split('?')[0]
    if not path.exists():errors.append({'page':page['target'],'missing_local_reference':link})
    stats['relative_links']+=1
  for i,s in enumerate(target.xpath('//script[not(@src)]')):
   if s.get('type') not in [None,'text/javascript','module'] or not (s.text or '').strip():continue
   with tempfile.NamedTemporaryFile(suffix='.js',mode='w') as f:
    f.write(s.text);f.flush();r=subprocess.run(['node','--check',f.name],text=True,capture_output=True)
   if r.returncode:errors.append({'page':page['target'],'script':i,'syntax':r.stderr})
   stats['inline_js']+=1
  for s in target.xpath('//script[@type="application/ld+json"]'):
   value=json.loads(s.text)
   def walk(v):
    if isinstance(v,dict):
     if v.get('@type')=='Book' and 'inLanguage' in v:
      assert v['inLanguage']=='en',('English product mislabeled PL',page['target']);stats['book_language_en']+=1
     for x in v.values():walk(x)
    elif isinstance(v,list):
     for x in v:walk(x)
   walk(value)
 for p in out.rglob('*.js'):
  r=subprocess.run(['node','--check',str(p)],text=True,capture_output=True)
  if r.returncode:errors.append({'file':str(p),'syntax':r.stderr})
  stats['external_local_js']+=1
 assert not (out/'pl/guides').exists(),'Approved Guides must remain external and untouched'
 result={'status':'PASS' if not errors else 'FAIL','stats':stats,'errors':errors,'surface_fit':'NOT_RUN','browser_interaction':'NOT_RUN','publication':False,'scope':'Source structure/CSS and generated syntax/references only; native and meaning reviews are separate evidence.'}
 (out/'VERIFICATION.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n');print(json.dumps(result,ensure_ascii=False));assert not errors
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('output',type=Path);verify(a.parse_args().output)
