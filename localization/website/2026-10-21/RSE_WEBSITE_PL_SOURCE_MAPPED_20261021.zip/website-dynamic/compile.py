"""Apply reviewed dynamic copy to exact frozen JS literal spans and JSON pointers.

Call BEFORE static HTML DOM localization. Output stays in localization-owned preview.
Never run this on a mutable production worktree.
"""
from pathlib import Path
import argparse,json,hashlib,re,subprocess,html
ROOT=Path(__file__).resolve().parent

def digest(s):return hashlib.sha256(s.encode()).hexdigest()
def read(path):return json.loads(Path(path).read_text())
def target_map(path):return {u['id']:u['text'] for u in read(path)['segments']}
def escape_fragment(s):
 # Escaping both quote kinds is safe inside either source JS literal quote.
 return s.replace('\\','\\\\').replace("'","\\'").replace('"','\\"').replace('\r','\\r').replace('\n','\\n')
def translated(item,dynamic,static):
 sid=item.get('id')
 if item.get('protected_identity'):return item.get('value')
 if sid in dynamic:return dynamic[sid]
 if sid in static:return static[sid]
 raise ValueError('Missing translation '+str(sid))
def replacement(item,value):
 kind=item.get('kind')
 if kind=='js-template':
  val=value.replace('\\','\\\\').replace('`','\\`')
  for i,expr in enumerate(item['expressions'],1):val=val.replace('{js_expr_'+str(i)+'}',expr)
  if re.search(r'\{js_expr_\d+\}',val):raise ValueError('Unresolved expression token')
  return '`'+val+'`'
 if kind=='literal-fragment':return escape_fragment(value)
 return json.dumps(value,ensure_ascii=False)
def build_maps(dynamic_candidate,static_candidate=None):
 dynamic=target_map(dynamic_candidate);static=target_map(static_candidate) if static_candidate else {}
 if static_candidate:
  units=read(ROOT.parent/'website-work/analysis-units.json')
  static.update({u['text']:static[u['id']] for u in units if u['id'] in static})
 src=read(ROOT/'source.json');expected=[x['id'] for x in src['segments']]
 if list(dynamic)!=expected:raise ValueError('Candidate ID order/coverage mismatch')
 for u in src['segments']:
  if u.get('protected') and dynamic[u['id']]!=u['text']:raise ValueError('Implementation literal changed: '+u['id'])
 for name in ["motto","wordhunt"]:
  candidate=ROOT/name/"candidate.json"
  if candidate.exists():
   extra=target_map(candidate);expected_extra=[x["id"] for x in read(ROOT/name/"source.json")["segments"]]
   if list(extra)!=expected_extra:raise ValueError("Incomplete gift candidate "+name)
   dynamic.update(extra)
 return dynamic,static

def apply_to_file(rel,text,dynamic,static):
 expected=read(ROOT/'DYNAMIC_SOURCE_FILES.json').get(rel)
 if expected and digest(text)!=expected:raise ValueError('Source changed before dynamic patch: '+rel)
 main=read(ROOT/'occurrences.json');sup=read(ROOT/'supplement-occurrences.json');dupes=read(ROOT/'static-duplicates.json')
 items=[x for x in main+sup+dupes if x['page']==rel and x.get('kind')!='json' and not x.get('protected_identity')]
 for name in ['motto','wordhunt']:
  if any(k.startswith(name+'.') for k in dynamic):items.extend(x for x in read(ROOT/name/'occurrences.json') if x['page']==rel)
 patches=[];seen={}
 if rel=='index.html':
  locale_literals={"'hmCalmEnergyState'":'hmCalmEnergyState:pl',"'hmOneMinuteState'":'hmOneMinuteState:pl',"'hmWordHuntState'":'hmWordHuntState:pl'}
  if any(k.startswith('wordhunt.') for k in dynamic):locale_literals["'ABCDEFGHIJKLMNOPQRSTUVWXYZ'"]='AĄBCĆDEĘFGHIJKLŁMNŃOÓPQRSŚTUUVWXYZŹŻ'
  if any(k.startswith('wordhunt.') for k in dynamic):
   a=text.index('    function buildGrid(wordList) {');b=text.index('    function renderGrid()',a)
   original=text[a:b];fixed=original.replace('function buildGrid(wordList)', 'function buildGridAttempt(wordList)',1)+(ROOT/'wordhunt/runtime-fix.js').read_text()
   patches.append((a,b,fixed,'locale-grid-integrity'))
  for raw,new in locale_literals.items():
   if text.count(raw)!=1:raise ValueError('Locale literal source changed '+raw)
   a=text.index(raw);patches.append((a,a+len(raw),json.dumps(new,ensure_ascii=False),'locale-mechanics'))
 for x in items:
  # Original capture uses field=... and no kind for JS literal; duplicates can use static map by exact source value.
  if 'id' not in x:
   # Parent supplies exact English→PL map for duplicated static values separately.
   if x.get('value') not in static:continue
   val=static[x['value']]
  else:val=translated(x,dynamic,static)
  alt_path=ROOT/'alt-native-proposals.json'
  if alt_path.exists():
   for alt in read(alt_path)['proposals']:
    if x.get('id')==alt['unit_id']:
     old='alt="'+alt['current_values'][0]+'"';new='alt="'+html.escape(alt['proposed_polish_value'],quote=True)+'"'
     if val.count(old)!=1:raise ValueError('Cover alt source changed '+str(x.get('id')))
     val=val.replace(old,new)
  if x['start'] in seen:
   if seen[x['start']]!=x['end']:raise ValueError('Overlapping starts')
   continue
  seen[x['start']]=x['end']
  assert text[x['start']:x['end']]==x['raw'],(rel,x['start'])
  if x.get('value')==val:continue
  patches.append((x['start'],x['end'],replacement(x,val),x.get('id','static-duplicate')))
 patches.sort()
 for before,after in zip(patches,patches[1:]):
  if before[1]>after[0]:raise ValueError('Overlapping exact literal replacements '+str((before,after)))
 out=[];offset=0
 for a,b,value,sid in patches:out.extend([text[offset:a],value]);offset=b
 out.append(text[offset:]);result=''.join(out)
 # Catalog locale routing is an explicit noncopy dependency, not an invented storefront.
 if rel=='assets/js/rse-experience-hub.js':
  if result.count('"/data/rse-format-options.json"')!=1:raise ValueError('Catalog source route changed')
  result=result.replace('"/data/rse-format-options.json"','"/pl/data/rse-format-options.json"')
  result=result.replace('"/assets/content/rse-detective-dossier.txt"','"/pl/assets/content/rse-detective-dossier.txt"')
  result=result.replace('^\\/assets\\/content\\/rse-','^\\/pl\\/assets\\/content\\/rse-')
 return result,{'path':rel,'source_sha256':digest(text),'output_sha256':digest(result),'literal_changes':len(patches),'changed_ids':[x[3] for x in patches]}

def apply_json(rel,value,dynamic,static):
 import copy
 result=copy.deepcopy(value);n=0
 for x in read(ROOT/'supplement-occurrences.json'):
  if x['page']!=rel or x.get('kind')!='json' or x.get('protected_identity'):continue
  new=translated(x,dynamic,static);node=result
  for part in x['pointer'][:-1]:node=node[part]
  key=x['pointer'][-1]
  if node[key]!=x['value']:raise ValueError('JSON pointer source changed')
  node[key]=new;n+=1
 # Locale rebinding only; no merchant URLs or format states are altered.
 for v in result.get('experiences',{}).values():
  url=v.get('editorialUrl')
  if isinstance(url,str) and url.startswith('/assets/content/'):
   v['editorialUrl']='/pl'+url
 return result,n

def finalize_preview(output_root):
 """Install the separately compiled localized iframe source after page assembly."""
 import importlib.util
 path=ROOT/'studio/compile.py'
 if not (ROOT/'studio/targets.pl.json').exists():raise ValueError('Studio native targets missing')
 spec=importlib.util.spec_from_file_location('rse_studio_compile',path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 content=module.compile_studio();target=Path(output_root)/'pl/assets/word-search-studio/inline.js';target.parent.mkdir(parents=True,exist_ok=True);target.write_text(content)
 return {'path':str(target),'sha256':digest(content),'status':'LOCAL_PREVIEW_ONLY'}

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--candidate',required=True);ap.add_argument('--static-candidate');ap.add_argument('--source-root',required=True);ap.add_argument('--output',required=True);a=ap.parse_args()
 dynamic,static=build_maps(a.candidate,a.static_candidate)
 out=Path(a.output);out.mkdir(parents=True,exist_ok=False);receipts=[]
 for rel in read(ROOT/'DYNAMIC_SOURCE_FILES.json'):
  p=Path(a.source_root)/rel
  if rel.endswith('.json'):
   value,n=apply_json(rel,read(p),dynamic,static);new=json.dumps(value,ensure_ascii=False,indent=2)+'\n';receipt={'path':rel,'pointer_changes':n,'source_sha256':digest(p.read_text()),'output_sha256':digest(new)}
  else:new,receipt=apply_to_file(rel,p.read_text(),dynamic,static)
  target=out/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(new);receipts.append(receipt)
 (out/'DYNAMIC_PATCH_REPORT.json').write_text(json.dumps(receipts,indent=2)+'\n')
 print(json.dumps({'files':len(receipts),'output':str(out)}))
if __name__=='__main__':main()
