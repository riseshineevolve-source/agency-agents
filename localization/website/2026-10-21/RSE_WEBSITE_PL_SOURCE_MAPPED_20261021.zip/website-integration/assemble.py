#!/usr/bin/env python3
"""Build isolated PL candidate from frozen EN; never writes Website Factory sources."""
from pathlib import Path
from lxml import html
import json,hashlib,importlib.util,os,re,argparse
ROOT=Path(__file__).resolve().parent.parent
def read(p):return json.loads(p.read_text())
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
def assemble(out):
 work=ROOT/'website-integration/work';work.mkdir(exist_ok=True)
 for name in ['analysis-units.json','occurrences.json','source-pages.json']:
  a=read(ROOT/'website-work'/name);b=read(ROOT/'website-legal'/name)
  if name=='analysis-units.json':
   b += [{'id':x['id'],'text':x['text'],'kind':'runtime'} for x in read(ROOT/'website-legal/source.json')['segments'] if x['id'].startswith('consent.')]
  save(work/name,a+b)
 static=read(ROOT/'website-work/candidate.json');legal=read(ROOT/'website-legal/targets.pl.json');static['segments']+=legal
 save(work/'candidate.json',static)
 spec=importlib.util.spec_from_file_location('builder',ROOT/'website-work/build_preview.py');builder=importlib.util.module_from_spec(spec);spec.loader.exec_module(builder)
 report=builder.build(ROOT/'website-source',work,out,work/'candidate.json',ROOT/'website-dynamic/candidate.json')
 # Conservative legal copy and consent UI share reviewed labels, implementation is unchanged.
 targets={x['id']:x['text'] for x in legal};text=(ROOT/'website-source/assets/js/rse-analytics-consent.js').read_text();patches=read(ROOT/'website-legal/consent-occurrences.json')
 for p in sorted(patches,key=lambda x:x['start'],reverse=True):
  assert text[p['start']:p['end']]==p['raw']
  text=text[:p['start']]+json.dumps(targets[p['id']],ensure_ascii=False)+text[p['end']:]
 text=text.replace('"/privacy/"','"/pl/privacy/"');p=out/'pl/assets/js/rse-analytics-consent.js';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 for page in (out/'pl').rglob('*.html'):
  doc=html.fromstring(page.read_bytes())
  for script in doc.xpath('//script[@src]'):
   if script.get('src').endswith('/assets/js/rse-analytics-consent.js'):script.set('src',os.path.relpath(p,page.parent))
  page.write_bytes(html.tostring(doc,encoding='utf-8',doctype='<!doctype html>'))
 # Supplement module handles the separately reviewed Word Search Studio HTML container.
 spec=importlib.util.spec_from_file_location('dynamic',ROOT/'website-dynamic/compile.py');dyn=importlib.util.module_from_spec(spec);spec.loader.exec_module(dyn)
 if hasattr(dyn,'finalize_preview'):dyn.finalize_preview(out)
 # Schema-only English source is separately authored and reviewed, rather than
 # silently replacing it with nearby visible text that might state other facts.
 schema_targets={x['id']:x['text'] for x in read(ROOT/'website-schema/targets.pl.json')};schema_pages={}
 for item in read(ROOT/'website-schema/occurrences.json'):schema_pages.setdefault(item['page'],[]).append(item)
 for rel,items in schema_pages.items():
  page=out/'pl'/rel;doc=html.fromstring(page.read_bytes());scripts=doc.xpath('//script[@type="application/ld+json"]');values={}
  for item in items:
   ix=item['jsonld_index'];value=values.setdefault(ix,json.loads(scripts[ix].text));node=value
   for part in item['pointer'][:-1]:node=node[part]
   key=item['pointer'][-1];assert node[key]==item['source_value'],(rel,item['id'],node[key]);node[key]=schema_targets[item['id']]
  for ix,value in values.items():scripts[ix].text=json.dumps(value,ensure_ascii=False)
  page.write_bytes(html.tostring(doc,encoding='utf-8',doctype='<!doctype html>'))
 report['legal_candidate_sha256']=hashlib.sha256((ROOT/'website-legal/targets.pl.json').read_bytes()).hexdigest()
 report['pages']=[dict(p,target_sha256=hashlib.sha256((out/p['target']).read_bytes()).hexdigest()) for p in report['pages']]
 save(out/'BUILD_REPORT.json',report)
 return report
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--output',required=True,type=Path);a=ap.parse_args();r=assemble(a.output);print(json.dumps({'pages':len(r['pages']),'output':str(a.output)}))
