import json,hashlib
from pathlib import Path
p=Path('website-work/targets.pl.json');data=json.loads(p.read_text());rest=[s for s in data if 390<=int(s['id'][4:])<=1180]
I={
'web.0404':('wracacie do dnia','Kalka nieopisująca naturalnie powrotu do zajęć.','wracacie do swoich zajęć'),
'web.0439':('wspiera otuchę','Nieidiomatyczne połączenie; otuchy się dodaje.','dodaje otuchy, ułatwia współpracę i wspiera rozwój emocjonalny'),
'web.0450':('Czy Darmowe materiały są płatne?','Pytanie jest logicznie zbędne przez gotową odpowiedź w nazwie kategorii.','Czy za korzystanie z materiałów trzeba płacić?'),
'web.0467':('Skupienie i cierpliwość przez przyjemną łamigłówkę, bez szkolnego ćwiczenia.','Rzeczownikowy skrót jest nieidiomatyczny i zaciera sens.','Przyjemna łamigłówka pomaga ćwiczyć skupienie i cierpliwość, bez poczucia odrabiania lekcji.'),
'web.0502':('Zobacz książkę w {slot_2}Amazon','Nienaturalny przyimek i brak odmiany nazwy w polskim CTA.','Zobacz książkę na {slot_2}Amazonie'),
'web.0518':('sposoby z mniejszą liczbą wymagań','Niejasne: sposoby same nie mają wymagań; odbiorca nie wie, o co chodzi.','sposoby na codzienność, które stawiają dziecku mniej wymagań'),
'web.0545':('w naszej {slot_2}specjalnej sekcji Darmowe materiały','Nazwa sekcji nie została oddzielona; zdanie składa się niezręcznie.','w naszej {slot_2}sekcji „Darmowe materiały”'),
'web.0557':('albo rozchmurzcie i dodajcie sobie energii','Brak zaimka zwrotnego przy „rozchmurzyć się”.','albo rozchmurzcie się i dodajcie sobie energii'),
'web.0565':('pełnowymiarowe wykreślanki','„Pełnowymiarowe” nie ma tu jasnego znaczenia dla użytkownika.','wykreślanki do druku'),
'web.0594':('Zaproś zachętę do odkrywania','Nieidiomatyczne, niezrozumiałe połączenie.','Odkrywaj razem z nami'),
'web.0597':('Siebie? Z przyjemnością potrafią się z siebie pośmiać.','„Siebie?” nie łączy się logicznie z poprzednim „traktują poważnie”; powtórzone „siebie”.','Z siebie za to chętnie się śmieją.'),
'web.0607':('Bezpłatne materiały pomagają stawiać nowe kroki z','„Stawiać nowe kroki” jest kalką; elipsa w całym zdaniu zostawia „nowe treści zmieniać się” i utrudnia rozpoznanie podmiotu.','Bezpłatne materiały pomagają Ci zrobić pierwszy krok z {slot_2}RISE{slot_3}, {slot_4}przydatne pomoce pozwalają rozwijać mocne strony z {slot_5}SHINE{slot_6}, {slot_7}a nowe treści zachęcają do dalszego rozwoju z {slot_8}EVOLVE{slot_9}.'),
'web.0694':('ma w sobie możliwości, by','Nienaturalna konstrukcja, szczególnie jako wprowadzenie do angielskiego hasła.','może'),
'web.0701':('masz w sobie możliwość, by','Kalka: w sobie można mieć siłę lub potencjał, ale nie „możliwość”.','możesz'),
'web.0769':('Mam wartość taki, jaki jestem.','Nieidiomatyczne hasło w języku dziecka.','Jestem ważny taki, jaki jestem.'),
'web.0770':('masz wartość bez warunków','Nienaturalny abstrakcyjny zwrot.','jesteś ważny bez żadnych warunków'),
'web.0800':('Przednia okładka','Techniczna kalka w zwykłym opisie obrazka.','Okładka'),
'web.0803':('Przednia okładka','Techniczna kalka w zwykłym opisie obrazka.','Okładka'),
'web.0805':('Przednia okładka','Techniczna kalka w zwykłym opisie obrazka.','Okładka'),
'web.0813':('Przednia okładka','Techniczna kalka w zwykłym opisie obrazka.','Okładka'),
'web.0837':('Widok do druku lub na lodówkę','Widok nie trafia na lodówkę; etykieta miesza ekran z wydrukiem.','Wydrukuj i powieś na lodówce'),
'web.0868':('krótkich chwilach uwagi','Nienaturalne połączenie; prawdopodobnie chodzi o krótki czas skupienia dziecka.','krótkich chwilach skupienia'),
'web.0881':('codzienne umiejętności podane przez krótką historię','Umiejętności nie są „podane przez historię”; kalkowana konstrukcja zaciemnia opis.','umiejętności przydatne na co dzień, przedstawione w krótkiej historii'),
'web.0891':('Trwają prace produkcyjne do wydania w KDP.','Niepoprawna łączliwość „prace do wydania”; wewnętrzny żargon produkcyjny.','Przygotowujemy ją do wydania w KDP.'),
'web.0900':('chwila zauważania','Niejasny, nienaturalny rzeczownik.','chwila uważności'),
'web.0909':('24 krótkie dni','Dni nie są krótkimi aktywnościami; błąd sensu w opisie zawartości.','24 krótkie aktywności, po jednej na każdy dzień'),
'web.0911':('około 8–12 lat','Sprzeczność wewnątrz polskiej witryny: web.0146 podaje dla świątecznej książki 4–14 lat, tutaj i web.0931 około 8–12. Trzeba ustalić jeden zakres z właścicielem źródła faktów.','Ujednolicić zakres wieku z potwierdzonym zakresem dla tego konkretnego wydania; bez samodzielnego wyboru liczby.'),
'web.0917':('linku do Amazon','Brak naturalnej odmiany nazwy w polskim zdaniu.','linku do Amazona'),
'web.0931':('około 8–12 lat','Powtórzenie zakresu sprzecznego z web.0146 (4–14 lat) dla świątecznej książki.','Ujednolicić z potwierdzonym zakresem dla tego konkretnego wydania.'),
'web.0940':('Krótkie, uważne zatrzymania','Nienaturalna nominalizacja; dziecko wykonuje ćwiczenie, nie „uważne zatrzymanie”.','Krótkie chwile uważności'),
'web.0949':('wsparcie w budowaniu pewności siebie, nastawieniu i radzeniu sobie','„Wsparcie w nastawieniu” jest nieidiomatyczne; wspólny przyimek nie pasuje do wyliczenia.','wsparcie w budowaniu pewności siebie, rozwijaniu nastawienia na naukę i radzeniu sobie'),
'web.0964':('Dla jakiego wieku powstaje?','Kalka składniowa.','Dla dzieci w jakim wieku powstaje?'),
'web.0967':('prace produkcyjne nad książką drukowaną do wydania w KDP','Żargon i nieidiomatyczne połączenie „prace … do wydania”.','prace nad przygotowaniem książki drukowanej do wydania w KDP'),
'web.0971':('Przekazana przez właściciela projektu grafika przedniej okładki','Wewnętrzny język przekazywania plików trafia do FAQ dla rodzin; „przednia okładka” brzmi technicznie.','Pokazana grafika okładki'),
'web.0977':('Trwają prace produkcyjne do wydania w KDP.','Niepoprawna łączliwość „prace do wydania”.','Przygotowujemy książkę do wydania w KDP.'),
'web.0985':('Czarno-białe kolorowanie','Sugeruje kolorowanie wyłącznie bielą i czernią, zamiast czarno-białych plansz do kolorowania.','Czarno-białe ilustracje do kolorowania'),
'web.0987':('Czarno-białe kolorowanie','Sugeruje kolorowanie wyłącznie bielą i czernią, zamiast czarno-białych plansz do kolorowania.','Czarno-białe ilustracje do kolorowania'),
'web.1016':('linkami do Amazon','Brak naturalnej odmiany w polskim zdaniu.','linkami do Amazona'),
'web.1051':('Czarno-białe kolorowanie z iluzją','Niejasna etykieta, sugerująca kolorowanie wyłącznie czernią i bielą.','Czarno-białe ilustracje z iluzjami optycznymi'),
'web.1057':('Dokładne zalecenie wiekowe','Urzędowa, nienaturalna konstrukcja w opisie dla rodziny.','Zalecany przedział wieku'),
'web.1089':('Jakie umiejętności obejmuje World 01?','Odpowiedź wylicza tematy i emocje (nudę, złość), a nie umiejętności.','Jakie tematy obejmuje World 01?'),
'web.1134':('wszystkich angielskich ścieżek','Opis polskiej witryny bez wyjaśnienia nazywa wszystkie ścieżki angielskimi; błąd perspektywy językowej.','wszystkich ścieżek'),
'web.1144':('ćwiczyć radzenie sobie z trudnościami i emocjami, codzienne zwyczaje, nawyki, umiar w korzystaniu z ekranów oraz podejmowanie decyzji','Czasownik „ćwiczyć” nie pasuje do zwyczajów, nawyków i umiaru w tym szeregu.','radzić sobie z trudnościami i emocjami, rozwijać pomocne zwyczaje i nawyki, zachowywać umiar w korzystaniu z ekranów oraz ćwiczyć podejmowanie decyzji'),
'web.1147':('o wielkich emocjach, ogromnej energii i niekończących się okazjach do nauki','„O okazjach” nie opisuje osoby; wymuszone wyliczenie.','pełne emocji i energii, które ciągle uczy się czegoś nowego'),
'web.1166':('Przygotowywany Project Unstoppable szuka praktycznych sposobów myślenia i trwalszych nawyków','Projekt nie „szuka nawyków”; nienaturalna personifikacja w praktycznym opisie produktu.','W Project Unstoppable przygotowujemy praktyczne wskazówki, które pomogą przyjrzeć się własnemu sposobowi myślenia i wypracować trwalsze nawyki')
}
old=json.loads(Path('website-work/review-native-batch01.json').read_text())
oldmap={r['id']:r for r in old['reviews']};snapshot={s['id']:s['text'] for s in json.loads(Path('website-work/batches/batch01/targets.pl.json').read_text())}
reviews=[]
for s in rest:
 r={'id':s['id'],'sha256':hashlib.sha256(s['text'].encode()).hexdigest(),'status':'FIX' if s['id'] in I else 'KEEP'}
 if s['id'] in I:
  a,b,c=I[s['id']];r.update(phrase=a,reason=b,minimal_fix=c)
 reviews.append(r)
closure=[]
for s in data:
 if int(s['id'][4:])>389: continue
 r={'id':s['id'],'sha256':hashlib.sha256(s['text'].encode()).hexdigest(),'changed_since_batch01':s['text']!=snapshot[s['id']]}
 if s['id'] in ['web.0338','web.0339']:
  r.update(status='KEEP',evidence='Prior status recommendation retracted: Planowane is explicitly locked.')
 elif not r['changed_since_batch01']:
  r.update(status=oldmap[s['id']]['status'],evidence='Unchanged reviewed Polish text; batch01 finding retained.' if oldmap[s['id']]['status']=='FIX' else 'Unchanged reviewed Polish text.')
 else:r.update(status='REQUIRES_REVIEW',evidence='Text changed after reading; do not count this hash as reviewed.')
 closure.append(r)
out={'reviewer_role':'Native Polish / Anti-AI + audience reviewer','scope':{'input':str(p),'segments_newly_reviewed':len(rest),'range':'web.0390–web.1180','first389_closure_check':len(closure),'source_language_seen':False,'candidate_edited':False,'method':'Read all 791 Polish segments, treating inline markers as formatting boundaries, and read related adjacent units together. Prior389 checked for changes against previously reviewed hashes.'},'counts_new':{'KEEP':len(rest)-len(I),'FIX':len(I),'BLOCK':0},'first389_counts':{k:sum(r['status']==k for r in closure) for k in ['KEEP','FIX','BLOCK','REQUIRES_REVIEW']},'notes':['Planowane retained as explicit locked status label; prior web.0338/0339 recommendations retracted.','Cross-segment age discrepancy needs fact reconciliation; reviewer does not choose factual range.','No human native panel, owner approval or overall publication PASS claimed.','Split brand-led phrases such as Każde dziecko może RISE are intentional branding and not normalized.'], 'reviews':reviews,'first389_closure':closure}
Path('website-work/review-native-rest.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(out['counts_new']);print(out['first389_counts'])
