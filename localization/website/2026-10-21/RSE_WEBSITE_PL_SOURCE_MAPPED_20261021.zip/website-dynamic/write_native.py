import json
from pathlib import Path
base=Path('/workspace/scratch/e6eabdc4c3a0/website-dynamic')
p={}
def put(n,s):p[f'dynamic.{n:04}']=s
def cards(start,rows):
 for i,row in enumerate(rows.strip().split('\n')):
  for j,s in enumerate(row.split('|')):put(start+3*i+j,s)
put(3,'Wybierz…')
cards(6,'''Trzy oznaki spokoju|Przez minutę poszukaj w myślach trzech oznak, że twoje ciało jest teraz bezpieczne. Zauważ każdą z osobna i pozwól sobie ją uznać.|Trzy dowody. Zamartwianie się może już zamknąć księgę.
Ścisz myśli|Przez minutę wyobrażaj sobie, że przy każdym wydechu ściszasz myśli o jeden stopień.|O, ciszej. Wreszcie słyszę własne myśli, a nie całe zebranie.
Spójrz szerzej|Przez minutę rozluźnij spojrzenie. Zamiast wpatrywać się w jeden punkt, zauważaj także to, co jest po bokach.|Krok w tył i widać więcej szczegółów. Ciekawe.
Można odpuścić|Przez minutę przy każdym oddechu wybieraj jedną część ciała i w myślach pozwalaj jej się rozluźnić.|Pozwolenie wydane. Bez pieczątki, za to z rozmachem.
Oddech bez atrakcji|Przez minutę oddychaj możliwie równo. Zauważaj powtarzający się rytm i sprawdź, jak ci z nim jest.|Zwyczajny oddech. Dziś awansuje na gwiazdę programu.
Jedno małe dziękuję|Przez minutę pomyśl o jednej rzeczy, za którą czujesz wdzięczność. Zamiast robić listę, zauważ, czy towarzyszy jej ciepło w ciele.|Jedno dziękuję wystarczy. Nie trzeba robić prezentacji!
Pogoda w środku|Przez minutę nazwij po cichu swoją emocję jak pogodę: deszcz, wiatr, słońce. Oddychaj i daj jej zmieniać się we własnym tempie.|Nie muszę gonić burzy. Mogę po prostu ją zauważyć.
Jedno prawdziwe zdanie|Przez minutę wracaj do jednego prawdziwego zdania, na przykład: „Jestem tutaj”, „Teraz jestem bezpiecznie” albo „To się zmienia”. Wybierz tylko takie, które pasuje do twojej sytuacji, i oddychaj.|Prawda ma tę zaletę, że dramat nie ma z nią o czym dyskutować.
Barki w dół|Przez minutę powoli krąż barkami. Gdy je opuszczasz, zrób wydech i wyobraź sobie, że opadają jak ciężka zasłona.|Sprawdzam, czy moja szyja chce już wysłać podziękowanie.
Ściana do pomocy|Przez minutę delikatnie naciskaj dłońmi na ścianę przy wydechu. Na wdechu zwalniaj nacisk.|Ściana: asystent, który zawsze stoi na stanowisku.
Stopy jak korzenie|Stań na minutę z lekko ugiętymi kolanami. Wyobraź sobie korzenie wyrastające ze stóp i rób długie wydechy.|Dąb ma świetną postawę. I ani razu nie był na kursie.
Zaciśnij i puść|Przez minutę powtarzaj: łagodnie zaciśnij dłonie na 2 sekundy, a potem otwieraj je przez 4 sekundy.|Odpuszczanie w wersji luksusowej. Cały sprzęt masz pod ręką.
Tak, nie, spokojnie|Przez minutę delikatnie potakuj głową, a potem łagodnie kręć nią na „nie”. Oddychaj równo.|Moje ciało właśnie powiedziało spokojowi „tak”.
Przytulenie dla siebie|Przez minutę obejmuj się ramionami. Utrzymuj delikatny nacisk i wydłużaj wydechy.|Mam własną przytulną kryjówkę. Wchodzę bez hasła!
Szczęka ma wolne|Przez minutę rozluźniaj żuchwę i pozwalaj językowi spokojnie spoczywać.|Szczęka też zasługuje na wolne. Tyle spraw dziś przeżuła.
Wydech trochę dłużej|Przez minutę rób zwykły wdech, a po nim wydech nieco dłuższy od wdechu.|Wydech dostał zadanie. Obyło się bez negocjacji.
Ciche „haa”|Przez minutę wydychaj powietrze jak przy bezgłośnym „haa”. Bez liczenia.|Pełna elegancja. Nawet westchnienie nie robi zamieszania.
Mrucz na wydechu|Przez minutę delikatnie mrucz przy każdym wydechu. Zauważaj wibracje w klatce piersiowej.|Wygląda przytulnie. Brzmi przytulnie. Zostaję przy mruczeniu.
Zupa do ostudzenia|Przez minutę wydychaj powietrze tak, jakby trzeba było ostudzić zupę. Obserwuj barki i rób tak do chwili, gdy przestaną się unosić.|Zupa nie musi nawet istnieć. A i tak ma dziś ważne zadanie!
Cztery razy trzy|Przez minutę powtarzaj rytm: wdech przez 3 sekundy, zatrzymanie na 3, wydech przez 3 i zatrzymanie na 3.|Cztery kroki w stałej kolejności. Ta zagadka lubi porządek.
Westchnij bez teatru|Przez minutę delikatnie wzdychaj i pozwalaj sobie puszczać napięcie. Bez wielkich aktorskich westchnień.|Westchnienie skrojone na miarę. Bez dramatycznej peleryny.
Dłoń na klatce|Połóż dłoń na klatce piersiowej na minutę. Oddychaj powoli i zauważaj dotyk dłoni jako sygnał, by się zatrzymać.|Spokojna dłoń ma czasem więcej do powiedzenia niż przemowa.
Wydech jak wąż|Przez minutę rób ciche „ssss” przy wydechu. Pozwól rytmowi zwolnić, bez liczenia.|Tryb ninja. Słychać tylko „ssss”.
Razem, bez słów|Przez minutę siedź albo stój blisko rodziny. Oddychaj powoli. Nie trzeba rozmawiać.|Rodzinne spotkanie bez porządku obrad. Wreszcie.
Życzliwość w spojrzeniu|Przez minutę kieruj łagodne, życzliwe spojrzenie ku jednej osobie, a potem wracaj do zwykłego spojrzenia.|Mały błysk zamiast wielkiej przemowy!
Otwarta postawa|Przez minutę rozluźnij dłonie, rozkrzyżuj ręce i przyjmij otwartą postawę.|Ciało też umie powiedzieć „miło cię widzieć”. I to bez megafonu.
Gramy razem|Przez minutę oddychaj powoli i pomyśl o rodzinie jak o jednej drużynie. Wyobraź sobie, że wszystkim gra w środku ta sama muzyka.|Tryb współpracy włączony. Gramy do jednej bramki.
Trochę więcej miejsca|Przez minutę daj sobie i innym nieco więcej miejsca niż zwykle. Oddychaj i zauważ, jak wam z tym dystansem.|Uprzejmość w najlepszej rozdzielczości: każdy mieści łokcie.
Nasz znak na nowy początek|Przez minutę ćwiczcie rodzinny znak nowego początku: łagodny wyraz twarzy i opuszczone barki. Niech każdy umie go rozpoznać.|Nasz rodzinny protokół. Bardzo elegancki i całkiem bezgłośny.
Krąg z oddechem|Przez minutę stańcie razem w luźnym kręgu. Zostawcie sobie miejsce i oddychajcie powoli, po prostu będąc blisko.|Rodzina w kółeczku. Od razu robi się jakoś bardziej razem!
O 10% odważniej|Przez minutę wyprostuj się odrobinę bardziej i oddychaj równo. Wypróbuj postawę, w której jest miejsce na odwagę i życzliwość.|Odwaga nie musi podnosić głosu. Czasem tylko prostuje plecy.
Próba przed startem|Przez minutę wyobrażaj sobie początek następnej małej czynności. Zobacz, jak płynnie wykonujesz jej pierwszy krok.|Krótka próba przed rozpoczęciem. Bez rezerwowania sali.
Trzy pozy zwycięstwa|Przez minutę zmieniaj trzy spokojne pozy zwycięstwa. Oddychaj przy tym równo.|Trzy pozy, trochę punktów doświadczenia. Peleryna zbędna.
Mały ruch radości|Przez minutę lekko się uśmiechnij i wybierz jeden drobny ruch: kołysanie, podskok albo poruszenie barkiem.|Taki mały ruch, a ja już mam ochotę na następny!
Rozejrzyj się uważnie|Przez minutę poszerzaj pole widzenia i oddychaj równo. Spróbuj skupić uwagę bez napinania się w oczekiwaniu na kłopoty.|Czujność tak, alarm na całą okolicę niekoniecznie.''')
(base/'native-proposals.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
cards(111,'''Hasło bez mikrofonu|Przez minutę bezgłośnie układaj usta w swoje hasło dodające siły. Wyprostuj się i spróbuj zgrać słowa z postawą.|Próba mikrofonu w środku. Siła i życzliwość słyszą się doskonale.
Pewnie i bez ruchu|Przez minutę pozostań bez ruchu, z wyprostowaną sylwetką i spokojnym oddechem. Zauważ, na co masz w tej chwili wpływ.|Pewność siebie weszła po cichu. Nie potrzebuje fanfar.
Zaczynam teraz|Przez minutę przy każdym wydechu powtarzaj po cichu: „Zaczynam teraz”.|Początek już jest. Perfekcja może dołączyć później.
Marsz w miejscu|Przez minutę maszeruj w miejscu w równym rytmie, poruszając ramionami. Niech ruch łagodnie cię rozrusza.|Klasyka. Nogi znają ją bez instrukcji obsługi.
Na zmianę przez środek|Przez minutę dotykaj prawą dłonią lewego kolana, potem lewą dłonią prawego. Płynnie zmieniaj strony.|Prawa do lewej, lewa do prawej. Most otwarty.
Ramiona do startu|Przez minutę łagodnie wymachuj ramionami, jakby napędzały rakietę. Ruszaj się płynnie, ze stabilnym oparciem na ziemi.|Zgoda na start. Pod warunkiem zachowania rakietowej elegancji.
Skręt na przejaśnienie|Przez minutę powoli skręcaj tułów. Przy każdym skręcie zrób wydech i wyobraź sobie, że odgarniasz mgłę z myśli.|Mgła otrzymała uprzejmą prośbę o opuszczenie lokalu.
Lekkie stopy|Przez minutę stawiaj lekkie, przesuwane kroki jak na rozgrzewce. Cicho i z odrobiną zabawy.|Trener lubi taką pracę nóg. Podłoga też.
Miejsce na wdech|Przez minutę kieruj barki lekko do tyłu, a przy wdechu delikatnie unoś klatkę piersiową.|Sprawdzam, czy w tej postawie łatwiej mi zabłysnąć.
Palce w ruch|Przez minutę szybko dotykaj kciuka kolejnymi palcami. Reszta ciała może pozostać spokojna.|Energia w ukryciu. Zdradzają ją tylko palce.
Tupnij z wyczuciem|Przez minutę, z miękkimi kolanami, kontrolowanie dociskaj stopy do podłoża. Kieruj energię w dół.|Siła i spokój. Bardzo udana para.
Oddech z konfetti|Przez minutę wypuszczaj powietrze małymi, delikatnymi porcjami. Wyobraź sobie, że rozsypujesz oddechem konfetti.|Miniaturowe fajerwerki. I nikt nie musi potem zamiatać!
Chłodny powiew|Przez minutę wdychaj powietrze nosem i wydychaj je jak chłodny strumień. Wyobrażaj sobie, że przewietrzasz myśli.|Odświeżanie w toku. Proszę nie zamykać wyobraźni.
Jeden lwi wydech|Zrób jeden mocny wydech „HAA”, a potem oddychaj równo do końca minuty.|Ryk z dobrymi manierami. Bardzo proszę: HAA.
Trzy na trzy|Przez minutę rób wdech przez 3 sekundy i wydech przez 3 sekundy. Trzymaj się równego rytmu.|Rytm złapany. Można ruszać dalej.
Wdech mocy, wydech spokoju|Przez minutę wyobrażaj sobie moc przy wdechu i spokój przy wydechu.|Paliwo dobrze dobrane: trochę mocy, trochę świętego spokoju.
Mruczący rozruch|Przez minutę mrucz przy każdym wydechu. Spróbuj połączyć odrobinę energii ze spokojnym rytmem.|Stara sztuczka. Wciąż mam ochotę ją wypróbować.
Wdech po trochu|Przez minutę bierz małe, lekkie porcje wdechu, a potem rób jeden dłuższy wydech. Łagodnie i miarowo.|Sprawdzam ten mały napęd. Bez detektywistycznego pośpiechu.
Kołyszemy się razem|Przez minutę łagodnie kołyszcie się we wspólnym rytmie.|Razem łapiemy rytm. Przemówienie otwierające odwołane.
Cichy podziw|Przez minutę zauważ w myślach po jednej godnej uznania cesze osób, które widzisz. Sprawdź, czy pojawia się przy tym ciepło.|Takie ciepło chowam na potem. Moje sekretne paliwo!
Nasze rodzinne hasło|Przez minutę powtarzaj w myślach wasze rodzinne zawołanie. Ruszaj się z poczuciem, że razem możecie coś zrobić.|Rodzina z charakterem. Nawet gdy nie słychać ani słowa.
Podaj uśmiech dalej|Przez minutę przekazujcie sobie po kolei mały uśmiech wokół grupy. Bez słów.|Sprytna moc. Nie trzeba nawet włączać dźwięku.
Doceniam to, co pomaga|Przez minutę po cichu doceń jedną rzecz, która teraz ci pomaga. Zauważ, co daje ci poczucie sensu.|Dobre paliwo ma korzenie. Przynajmniej w mojej wyobraźni.
Mały plan w środku|Przez minutę niech każda osoba wybierze w myślach jeden mały następny krok. Zachowajcie ten zamiar dla siebie i chwilę przy nim pobądźcie.|Cicha współpraca na najwyższym szczeblu. Bez kalendarza spotkań.
Odwaga obok siebie|Przez minutę stań prosto blisko innych i oddychaj równo.|Siła drużyny odblokowana. Nikt nie musi grać sam.''')
put(192,'Zatrzymaj i zobacz')
put(193,'🎡 Zatrzymaj i zobacz')
cards(194,'''Apartament dla ciała|Przez minutę wyobraź sobie odpoczynek w pięciogwiazdkowym hotelu. Rozluźnij czoło, szczękę i barki, a potem oddychaj. Klucz jest u ciebie.|Apartament spokoju. W cenie pobytu żadnych pilnych spraw.
Pokój w szerokim kadrze|Przez minutę obejmij wzrokiem cały pokój, zamiast skupiać się na jednym problemie. Oddychaj, jakby obraz przeszedł w tryb kinowy.|Pokój jest jednak większy niż ten cały dramat.
Podłoga daje oparcie|Przez minutę przy każdym wydechu delikatnie dociskaj stopy do podłoża. Zauważaj ich oparcie, jak mały dowód pod stopami.|Dowód znaleziony. Podłoga nie zamierza wdawać się w rozmyślania.
Trzy dobre drobiazgi|Przez minutę poszukaj wokół siebie trzech małych dobrych rzeczy. Zauważ, jak odczuwasz w ciele te drobne odkrycia.|I ten drobiazg też się liczy. I tamten. O, jeszcze jeden!
Twarz o 10% życzliwsza|Przez minutę spróbuj mieć wyraz twarzy o 10% życzliwszy niż twoje myśli. Obserwuj, jak na to reagujesz.|Twarz ma też ustawienia luksusowe. Właśnie sprawdzam menu.
Barki bez abonamentu|Przez minutę, gdy tylko zauważysz napięte barki, opuść je raz i zrób dłuższy wydech.|Ten abonament na napięcie? Poproszę anulować.
Posegreguj myśli|Przez minutę nadawaj myślom ciche etykiety: „planowanie”, „obawa”, „wspomnienie”. Pozwalaj im przechodzić dalej bez wdawania się w rozmowę.|Filtr poczty działa. Nie wszystko wymaga natychmiastowej odpowiedzi.
Dłonie puszczają|Przez minutę trzymaj dłonie otwarte i rozluźnione. Nie ściskaj ich. Oddychaj powoli, jakby dłonie pokazywały, jak można odpuścić.|Otwarte dłonie. Może i resztę dnia da się potrzymać trochę lżej.
Gracz o 10% wyższy|Przez minutę siedź albo stój o 10% wyżej: wydłuż sylwetkę i zostaw barki luźne.|Punkty doświadczenia zdobyte. Peleryna nadal niepotrzebna.
Zapisz następny krok|Przez minutę trzymaj w myślach jedną małą czynność, którą zrobisz jako następną. Łagodnie do niej wracaj.|Punkt zapisu znaleziony. Już wiem, od czego zacznę.
Uśmiech prawie niewidoczny|Przez minutę pozwól sobie na delikatny, ledwie widoczny uśmiech i oddychaj powoli.|Taki mały błysk. A ja go widzę!
Prowadź o 20% wolniej|Przez minutę ruszaj się i oddychaj o 20% wolniej niż zwykle. Wyobraź sobie osobę, która spokojnie prowadzi grupę.|Siły nie mierzy się prędkością. Zwłaszcza przy rodzinnym wyjściu.
Gdzie ukryło się napięcie?|Przez minutę szukaj napięcia w ciele, jak małych lampek alarmowych. Każde zauważone miejsce rozluźnij raz.|Podejrzana znaleziona. To znowu szczęka.
Po prostu bądź|Przez minutę zrób przerwę od naprawiania, ulepszania i pouczania. Po prostu bądź i oddychaj równo.|Perfekcja dzwoniła. Nie odbieram.
Przerwa dla spojrzenia|Przez minutę patrz na neutralny przedmiot i powoli mrugaj.|Przerwa prezesa. Bez gości i prezentacji.
Wydech jak aksamit|Przez minutę rób wydech dłuższy od wdechu. Wyobrażaj sobie, że wygładza cię w środku jak miękka tkanina.|Aksamitna robota. Nawet bez maszyny do szycia.
Mały zachwyt|Przez minutę poszukaj jednej cicho niezwykłej rzeczy w tej chwili. Daj sobie czas na odrobinę zachwytu.|Można tak po prostu się zachwycić? To ja poproszę!
Głos z filmu przyrodniczego|Przez minutę, jeśli w ogóle coś powiesz, mów powoli i neutralnie, jak narrator filmu przyrodniczego.|Oto rodzina w swoim naturalnym środowisku. Próbuje złapać oddech.
Dłoń mówi „jestem”|Przez minutę trzymaj dłoń na klatce piersiowej i oddychaj równo. Potraktuj ten dotyk jak ciche przypomnienie obecności i poczucia bezpieczeństwa.|Moja dłoń mówi: „Jestem”. Sprawdzam, jak mi z tym jest.
Odłóż mały kamyk|Przez minutę wyobrażaj sobie jedną drobną irytację jako kamyk. Z każdym wydechem łagodnie odkładaj go na bok.|Mniej kamyków do noszenia. Więcej miejsca na życie.
Spojrzenie i powrót|Przez minutę kieruj życzliwe spojrzenie ku jednej osobie, a potem wracaj do neutralnego wyrazu twarzy. Powtarzaj.|Tak się łączymy. Bez kabli i wielkiej przemowy!
Cichy bohater|Przez minutę stój prosto i oddychaj powoli. Wypróbuj odwagę, która nie potrzebuje głośnego głosu.|Bohater nie musi krzyczeć. Może po prostu stać na swoim miejscu.
Blisko, daleko, pomiędzy|Przez minutę nasłuchuj najbliższego dźwięku, potem najdalszego i ciszy pomiędzy nimi.|Cisza też dostarcza wskazówek. Trzeba jej tylko posłuchać.
Rozluźnij cztery miejsca|Przez minutę po kolei rozluźniaj brwi, język, dłonie i brzuch. Zauważaj, ile napięcia odnajdujesz w tych miejscach.|Rozluźnienie. Luksus, do którego nie potrzeba rezerwacji.
Przycisk w opuszkach|Przez minutę powoli stykaj opuszki palców i oddychaj. Wyobraź sobie, że naciskasz ukryty przycisk nowego początku.|Sekretny przycisk jest w palcach! Tak go sobie wyobrażam.
Życzliwy głos w głowie|Przez minutę mów do siebie w myślach spokojnie i życzliwie, jak dobry trener. Odpocznij od dramatycznych monologów.|Wewnętrzny teatr odwołuje dzisiejszy spektakl.
Jedno słowo na teraz|Przez minutę oddychaj, wracając do jednego wybranego słowa: „stabilność”, „życzliwość” albo „odwaga”. Niech przypomina ci o twoim zamiarze.|Jedno słowo, a już inaczej patrzę na tę pogodę.
Twarz na przerwie|Przez minutę rozluźniaj usta i policzki. Wyobraź sobie, że twarz odpoczywa po stresującym dniu.|Minuta wolnego dla buzi. Zasłużyła!
Spokój rusza do pracy|Przez minutę oddychaj powoli i wyobrażaj sobie, jak potem płynnie wykonujesz jedną pomocną czynność.|Spokój też potrafi wstać z fotela i coś zrobić.
Mój rytm dnia|Przez minutę oddychaj równo. Wyobraź sobie, że zostawiasz na dniu swój podpis: działasz celowo, życzliwie i bez zbędnego poruszenia.|Tak. Ten nastrój mi odpowiada.
Wzrok na bramkę|Przez minutę wybierz jeden punkt w pokoju, pozostań bez ruchu i oddychaj powoli. Jak napastnik skupiony na bramce.|Skupienie też można trenować. Piłka na razie ma wolne.
Presja, którą wykorzystasz|Przez minutę stój stabilnie, otwórz klatkę piersiową, rozluźnij barki i oddychaj. Spróbuj potraktować presję jak paliwo do pewniejszego działania.|Presja ta sama. Ja próbuję zagrać inaczej.
Próba przed sytuacją|Przez minutę wyobraź sobie jedną sytuację z dzisiejszego dnia. Przećwicz w myślach spokojny oddech, wyraz twarzy i wybory.|Trening w głowie. Potem sprawdzę to w życiu.
Ładowanie przez stopy|Przez minutę delikatnie dociskaj stopy do podłoża przy każdym wydechu. Wyobraź sobie, że tak ładuje się twoja bateria.|Ładowarka pod stopami. W mojej wyobraźni działa bez kabla.
Jedna zasada na minutę|Wybierz jedną małą zasadę: wolny oddech, luźne barki albo spokojne dłonie. Trzymaj się jej przez całą minutę, bez odstępstw.|Minuta trzymania się zasady. Zobaczę, co zabiorę z niej na później.
Wypoleruj spokój|Przez minutę oddychaj powoli. Przy wydechu wyobrażaj sobie wygładzanie powietrza, jak przy polerowaniu szklanego ekranu.|Mózg ten sam. Właśnie sprawdzam inne ustawienia.
Misja: cichy uśmiech|Przez minutę spróbuj rozbawić się samą mimiką. Bez wydawania dźwięków.|Chichot na najwyższym poziomie wtajemniczenia. Nic nie słychać.
Od iskry do spokoju|Przez minutę wydłużaj wydech względem wdechu. Przy każdym rozluźniaj jeden mały alarm: brwi, szczękę, dłonie albo barki. Powtarzaj, aż poczujesz uspokojenie.|Mogę mieć talent dramatyczny i nadal próbować złapać spokój.
Trzy przeoczone szczegóły|Przez minutę rozglądaj się po pokoju. Zauważ po cichu trzy szczegóły, które wcześniej umykały twojej uwadze.|Spokój przyszedł w kurtce ciekawości. Całkiem mu do twarzy.
Sześć wydechów i od nowa|Przez minutę licz tylko wydechy, od 1 do 6. Po szóstym zacznij od nowa. Pozostaw twarz rozluźnioną.|Moja sekretna przewaga? Chwila na odświeżenie myśli.''')
(base/'native-proposals.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
def seq(start,rows):
 for i,s in enumerate(rows.strip('\n').split('\n')):put(start+i,s)
put(334,'Wyloguj się');put(340,'Ukryj hasło');put(342,'Zresetuj hasło');put(343,'Ustaw nowe hasło')
seq(344,'''Mimi to mama, która ogarnia posiłki, plany, dzieci, pytania i znikające skarpetki w tempie trudnym do zmierzenia. Spokojna? Niekoniecznie. Powolna? Nigdy. Skuteczna nawet w samym środku chaosu? Zdecydowanie.
Mimi sama mianowała się strażniczką rodzinnego stylu. Swobodę wyrażania siebie chroni jak skarb narodowy. Chaos jakoś zniesie, ale gryzące się kolory? Wtedy wkracza policja modowa. Czyli ona.
Myśli szybko, ripostuje jeszcze szybciej i bezbłędnie wyczuwa, gdzie znowu zrobił się bałagan. Codzienny rozgardiasz potrafi jednocześnie uporządkować i upiększyć. Ciepła i nie do zatrzymania, jest sercem rodziny oraz jej bardzo szybkim silnikiem.
Ninja od wielu spraw naraz
Tropicielka zgub
Nagina czas
Łagodzi rodzinne nastroje
Żongluje kalendarzem
Luli łączy twórczą wyobraźnię z elegancją i umysłem stratega. Uwielbia detektywów, tajemnice i książki, w których kolejny zwrot akcji zmienia wszystko.
Długie, gładkie włosy, błyszczące kolczyki i ubrania w odważnych kolorach od razu przyciągają wzrok. Ale Luli ma też siłę i świetną kondycję. Wspina się i biega szybciej od większości chłopców, zanim ci zdążą uznać, że to już zawody.
Na szarfach porusza się płynnie i pewnie, jakby grawitacja przyznała jej specjalne przywileje. Spokojna, elegancka i skłonna do namysłu, wnosi do towarzystwa ciepło. Z nią nawet zwykła chwila zyskuje odrobinę luksusu.
Umysł do tajemnic
Królowa stylu
Zbieraczka poszlak
Dyskretnie podsuwa pomysły
Zaczytana po uszy
Dilo ma naturalny talent do piłki i gier. Szybkie nogi, szybkie palce, szybkie opinie. Strzela obiema stopami i przeskakuje kolejne poziomy, jakby znał skróty. Bywa uparty, ale potrafi też zaskoczyć hojnością.
Ma 9 lat i sporo do powiedzenia o piłce, technologii oraz stylu. Jego postawione na żel kolce trzymają się nawet wtedy, gdy pogoda łamie parasole. Ciekawość i energię Dilo trudno zatrzymać tylko dla siebie.
Kiedy pojawia się Dilo, sprawy przyspieszają. I robią się ciekawsze.
Mały bramkowy potworek
Pogromca poziomów
Dowódca stylu
Gwiazda uporu
Hojny rozdawca smakołyków
Alio działa na 120% energii i ciekawości, z solidną porcją życzliwych psot. Skacze, buduje ogromne miasta z klocków, testuje i wynajduje rzeczy absolutnie niezbędne. Przynajmniej według niego.
Jego bardzo poważna sekwencja kung-fu trwa dokładnie 12 sekund i kończy się dramatyczną pozą oraz śmiechem. Gdy Alio milczy, prawdopodobnie właśnie powstaje plan. Zabawny, chaotyczny albo jedno i drugie.
Z Alio nuda nie ma gdzie usiąść.
Ekspert od podskoków
Uruchamia chaos
Wynalazca zabaw
Sprinter po przekąski
Rakietowy napęd zabawy
Nini jest malutka, ale jej radość zajmuje cały pokój, jeszcze zanim nadejdzie pora przekąski. Śpiewa, tańczy i chichocze. Świat jest jej sceną, a ona nie ma wątpliwości, kto tu jest gwiazdą.
Ma 4 lata i zarządza rodzinną gospodarką przytulania. Bez negocjacji. Wielkie oczy, wielkie serce i radość rozsypująca się wszędzie jak urodzinowe konfetti.
Maszyna do przytulania
Fabryka chichotu
Mała trąba powietrzna
Taniec na przycisk
Kropelka słońca
Bibi to babcia, która wiek traktuje jak drobną literówkę. Krótkie modne włosy, stylowe okulary i odważne, nowoczesne ubrania sprawiają, że każdy chodnik staje się jej wybiegiem. Często nawet o tym nie wie.
Ciepła, pełna energii i zawsze gotowa na przygodę, jeździ z wnukami na nartach i piecze muffiny znikające w kilka minut. W jodze też potrafi wygrać. A potem z urokiem o tym przypomnieć.
Gdyby fajne babcie potrzebowały światowej ambasadorki, Bibi miałaby tę posadę. Elegancja, niespożyta energia i pewność siebie godna królowej.
Cesarzowa stylu
Ikona energii
Magnes na przygody
Elegancja w ruchu
Dowódczyni zabawy''')
for n,s in {400:'Wpisz poprawny adres e-mail.',401:'Trwa wypisywanie…',403:'Wypisanie jest chwilowo niedostępne. Skontaktuj się z pomocą.',404:'Nie znaleziono tego adresu e-mail w bazie.',405:'Nie udało się wypisać z listy.',406:'Otwórz wiadomość w swojej skrzynce i potwierdź usunięcie konta.',407:'Wypisanie jest chwilowo niedostępne. Spróbuj ponownie później.',413:'Przeglądarka zablokowała wyskakujące okno.',418:'Te warunki dotyczą korzystania z witryny i materiałów edukacyjnych Rise.Shine.Evolve. Happy Me Adventures jest zapowiedziane w Google Play.',420:'Happy Me Adventures jest zapowiedziane w Google Play. Właściwe zasady sklepu dołączymy, gdy aplikacja będzie dostępna.',424:'Project Unstoppable jest zapowiedziane w Google Play. Warunki udostępnimy wraz z dostępną aplikacją.',425:'Project Unstoppable jest zapowiedziane w Google Play. Właściwe zasady sklepu dołączymy, gdy aplikacja będzie dostępna.'}.items():put(n,s)
seq(426,'''W grudniu plecaki, papier do pakowania i pilne „na jutro!” potrafią zająć cały dzień. Tu plan jest celowo mały: 10 minut, żeby pobyć rodziną, zamiast wyłącznie zespołem od logistyki.
Odliczajcie do świąt, bawiąc się w zwyczajne dni.
ZŁAPMY CHWILĘ / ZRÓBMY COŚ RAZEM / POGADAJMY
Krótka pauza, wspólna zabawa i okazja do rozmowy. A potem pomysł do wypróbowania jutro, żeby coś z tej chwili zostało z wami na kolejny dzień.
Bez przygotowań
Nie trzeba szykować prac plastycznych ani kupować materiałów. Do zabawy wystarczą już 2 osoby.
Chodzi o to, żeby naprawdę być razem w grudniu. Perfekcja nie jest warunkiem udziału.
W przygotowaniu. Zamówienia nie są jeszcze dostępne.
W przygotowaniu. Plik do pobrania nie jest jeszcze dostępny.
Kolorowanie z drugim dnem
Spójrz jeszcze raz. Co się tam ukryło?
Zwierzę wtapia się w otoczenie. Mocne czarne linie, otwarte białe pola i geometryczny rytm tworzą niecodzienną przygodę z kolorowaniem.
20 ilustracji
Starannie opracowywany zestaw ilustracji zwierząt.
Anatomia spotyka iluzję
Wzory przechodzą przez sylwetkę zwierzęcia i płynnie łączą ją z tłem.
Miejsce na twój kolor
Duże, wyraźne kształty zostawiają swobodę. Bez tłoku drobnych pól z numerami.
Ostateczny wybór ilustracji i szczegóły publikacji są jeszcze w przygotowaniu.
Niemożliwe perspektywy
Tutaj przestrzeń lubi zaskakiwać.
Niemożliwe pokoje, nieoczekiwane kąty, odbicia i czarno-białe wzory. Oprócz potworów czeka tu także tajemnica.
Głębia, która myli wzrok
Mocna geometria, spirale, odbicia i niezwykłe punkty widzenia.
Halloweenowi bohaterowie
W planowanej serii pojawią się różne postacie i scenerie.
Przestrzeń na kolor
Czarna, graficzna kreska i duże otwarte pola czekają na własne kolory.
Ilustracje i wydanie drukowane są jeszcze w przygotowaniu.
Babcia Bibi ma plan. A jej plany rzadko są całkiem przewidywalne.
Pomysły i wspólne aktywności z charakterem Bibi: rodzinna wyobraźnia, trochę twórczości i drobne psoty.
Rodzinny projekt
Twórcze pomysły i zabawa, w którą wchodzicie razem.
Pomysł nabiera kształtu
Aktywności twórcze są w opracowaniu. Szczegóły ostatecznego wydania nie zostały jeszcze potwierdzone.
Na razie pokazujemy projekt. Format i miejsce publikacji podamy po ich potwierdzeniu.
Szczegóły publikacji niepotwierdzone
Misje dla nastolatków
Mniej motywacyjnego gadania. Więcej misji, które mogą się przydać.
Powstaje interaktywna aplikacja na Androida dla nastolatków, o skupieniu, rutynach i samodzielnych codziennych wyborach.
Skupienie, nawyki i praktyczne wyzwania
Najpierw Android
Aplikacja na Androida jest nadal w opracowaniu. Nie ma jeszcze strony w Google Play.
Przed premierą nie podajemy płatnego dostępu, daty wydania ani dostępności w sklepie.
Małe misje, wielkie emocje i kolejne kroki przez zabawę.
Happy Makers zapraszają dzieci do zauważania uczuć, ćwiczenia pewności siebie i krótkich rodzinnych chwil.
Wielkie emocje
Zauważ emocję, nazwij sytuację i sprawdź, jak inaczej można zareagować.
Mała codzienna odwaga
Krótkie, wykonalne pomysły pomagają ćwiczyć pewność siebie w codziennych sytuacjach.
Razem jako rodzina
Zwykłe chwile stają się okazją do rozmowy, zabawy i wspólnego uczenia się.
Codzienna odwaga może rosnąć dzięki rozmowom, małym próbom i czasowi spędzanemu razem.
Książka opublikowana
Dostępna na Amazon
Czy to zbiór opowiadań?
To prowadzona przygoda na 31 dni, z codziennymi zachętami do ćwiczenia pewności siebie, uważności i otwartości na rozwój.
Ile czasu potrzeba każdego dnia?
Kilka minut. Większość rodzin czyta jedną stronę dziennie i wybiera jedno małe działanie do przećwiczenia.
Zwykłe chwile też mogą być prawdziwą przygodą.
10 zabawnych opowiadań z Happy Makers o emocjach po szkole, przyjaźni, błędach i nowych początkach. Przeczytajcie wspólnie jedną historię, a potem porozmawiajcie o jednym małym pomyśle na przyszłość.
10 poziomów opowieści
Krótkie, zabawne historie o codziennych emocjach.
Uczucia i przyjaźń
Zauważaj własne reakcje, słuchaj innych i próbuj odpowiadać inaczej.
Rodzinny czas bez ekranów
Opublikowana książka drukowana po angielsku do wspólnego czytania i rozmów.
Angielska książka drukowana jest opublikowana. Bieżące wydania, cenę, dostępność i dostawę sprawdzisz na Amazon. Aplikacja nie została jeszcze wydana.
Interaktywna aplikacja
Planowana. Jeszcze niewydana i niedostępna do pobrania.
Ile trwa jedna historia?
Przeczytajcie krótki poziom, zajrzyjcie do krótkiej części Neuro-Coaching Console i poświęćcie kilka minut na rozmowę.
Zeszyt ćwiczeń czy zbiór opowiadań?
To zabawne opowiadania. Każdy poziom zawiera proste wyjaśnienie działania mózgu i praktyczny kod do wypróbowania od razu.
Jakie umiejętności poznajemy w World 01?
World 01 porusza emocje po szkole, empatię, błędy, ciekawość zamiast nudy, sposoby radzenia sobie ze złością, rozwój, przyjaźń, dbanie o siebie i podstawy codziennej energii.
Nawyki zaczynają się od ciekawego pytania.
10 nowych historii Level Up Your Brain o ekranach, rutynach, współpracy i przemyślanych wyborach. Rozmowa ma wciągać, zamiast zamieniać się w pracę domową.
Zabawne historie o nawykach, rutynach i skupieniu.
Ekrany i równowaga
Przyjrzyjcie się swoim nawykom przy ekranach i zróbcie miejsce na inne zajęcia.
O czym jest World 02?
World 02 to dalsze ćwiczenia dla współczesnej rodziny: ekrany, rutyny, nawyki, słuchanie, współpraca i krytyczne myślenie.
Czy potrzeba na to dużo czasu?
Niewiele: jeden krótki poziom, Neuro-Coaching Console i jeden prosty kod do wypróbowania w życiu.
Czy są tu sposoby na czas przed ekranem?
Tak. Są poziomy o równowadze w korzystaniu z ekranów i o tym, co książka nazywa „dopaminowym wypaleniem”, przedstawione w sposób zrozumiały dla dzieci.
Czarna koperta. Znak 0. Zaproszenie do śledztwa z Happy Makers. Mapy, wskazówki, szyfry i dedukcja prowadzą przez sprawy, które łączą się w coraz większą tajemnicę.
Jedna zagadka, wiele tropów
30 połączonych akt sprawy, powracające dowody i jedna tajemnica rozwijająca się przez całą książkę.
Naprawdę jesteś detektywem
Wybierz kryptonim, otwieraj kolejne akta i pracuj na swój status detektywa.
Skarbiec podpowiedzi
Trudna wskazówka? Trzy poziomy pomocy naprowadzają na trop, zamiast od razu zdradzać pełne rozwiązanie.
Wskazówki czekają. Książka drukowana jest jeszcze w przygotowaniu.
Zapowiedź. Zamówienia nie są jeszcze dostępne.''')
seq(523,'''Koło energii się kręci! Kliknij jeszcze raz, by je zatrzymać i odkryć następny pomysł na rozruszanie.
Koło spokoju się kręci! Kliknij jeszcze raz, by je zatrzymać i odkryć ćwiczenie.
Filtr zmieniony. Zakręć kołem energii po kolejny wynik.
Filtr zmieniony. Zakręć kołem spokoju po kolejne ćwiczenie.''')
seq(528,'''Znalezione słowa: {js_expr_1} / {js_expr_2}
Wykreślanka {js_expr_1} ukończona!
Konto: {js_expr_1}
✅ Pobrano: {js_expr_1}
Otwórz Amazon ↗
Otwórz Google Play ↗
Otwórz App Store ↗
Otwórz potwierdzoną stronę produktu w 
Dostępne. Wybierz wydanie w 
Zobacz pełny opis książki
Wybierz format
Książka i aplikacja to odrębne wydania. Każde ma własny status, a linki pojawiają się po potwierdzeniu premiery.
Wydanie książkowe
Tu znajdziesz bieżący status publikacji. Link do sprzedawcy pojawi się, gdy wydanie będzie rzeczywiście dostępne.
Wydanie aplikacji
Tu znajdziesz bieżący status prac i pobierania. Link do sklepu pojawi się po potwierdzeniu premiery.
Zamknij szczegóły produktu
Książka &amp; aplikacja ↓
Co znajdziesz w środku
Dobrze wiedzieć
Jedna historia. Wybierz swój format.
Dostępne formaty
Książka i aplikacja to odrębne wydania. 
Każde wydanie ma własną dostępność. Link do zakupu pojawia się dopiero po publikacji.''')
(base/'native-proposals.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
units={u['id']:u for u in json.loads((base/'writer-packet.layout-tokens.json').read_text())['units']}
def html(n,rows):
 u=units[f'dynamic.{n:04}']; ss=rows.strip('\n').split('\n'); assert len(ss)==u['mechanics']['copy_slots'],(n,len(ss),u['mechanics']['copy_slots'])
 s=u['mechanics']['html_token_layout']
 for i,t in enumerate(ss,1):s=s.replace('{copy_%03d}'%i,t)
 put(n,s)
html(188,'Żadne ćwiczenie nie pasuje do wybranego filtra.')
html(394,'''ŚWIĘTA SĄ TEŻ PO DRODZE
Książka w przygotowaniu. Treść i okładka powstają, a publikacja i dostępność nie są jeszcze potwierdzone.
Zobacz podgląd angielskiej książki
Poznaj osobną aplikację Gentle Steps na Androida''')
html(395,'''Babcia Bibi zaprasza do tworzenia
Rodzinny projekt z kreatywnością i kolorowaniem. Publikacja, dostępność w sklepach i ostateczny czas trwania aktywności nie są jeszcze potwierdzone.
Zobacz aktualny opis projektu''')
html(412,'''Wypisanie potwierdzone
Twój dostęp został odebrany. Po potwierdzeniu zamkniemy to okno i wrócimy do głównej zakładki.
Rozumiem''')
html(414,'Ładowanie darmowych materiałów…')
html(415,'Ładowanie Word Search Studio…')
html(522,'''Towarzyszy ci:
Małe ćwiczenie dla rodziny''')
html(527,'Towarzyszy ci:')
html(391,'''31 dni odkrywania własnych możliwości
Zobacz drogę przez książkę
Kiedy emocje robią się większe od dziecka
Zmartwienia potrafią zajmować mnóstwo miejsca, a perfekcjonizm nie daje odetchnąć nawet po drobnym błędzie.
Jak pomóc dziecku usłyszeć własny głos, gdy dookoła słychać, jakie powinno być?
I jak porozmawiać o tym wszystkim, żeby rozmowa nie przypominała przesłuchania?
Ta książka zaprasza do krótkiej, twórczej przygody z emocjami.
To interaktywny zestaw pomysłów, do których dziecko może wracać i które może dopasowywać do siebie.
Bez konieczności znalezienia idealnych słów już na pierwszej stronie.
Trudny poziom? Zagrajmy razem
Codzienność bywa jak gra, w której nagle pojawia się trudniejszy poziom.
Nie trzeba przechodzić go samemu.
Poznaj swoich przewodników
Mimi, Luli, Dilo, Alio i Nini towarzyszą dziecku w odkrywaniu emocji i własnych mocnych stron.
Czasem życie przypomina kolejkę górską, a czasem aż chciałoby się narzucić pelerynę.
Tutaj jest miejsce i na takie chwile, i na spokojne poszukiwanie własnych sposobów działania.
Małe spotkanie każdego dnia
31 dni i 10 minut dziennie.
Krótka codzienna chwila na twórczą pracę, zauważenie uczuć i rozmowę.
Książka staje się osobistym zasobem
Po dniu 31 zostają własne odpowiedzi, odkrycia i pomysły dziecka.
Można do nich wracać, gdy kolejny dzień okaże się trudny.
To jego własna emocjonalna apteczka pomysłów
Pięć etapów jednej przygody
Najpierw poczucie oparcia, potem bliższe poznawanie uczuć i własnych możliwości.
Dalej relacje z innymi oraz marzenia o tym, co przed nami.
Każdy etap ma swój temat i zostawia przestrzeń na własne odpowiedzi.
Te pięć tygodni łączy się w drogę przez 31 dni.
Zobacz, co czeka po kolei.
Droga przez pięć tygodni
Tydzień 1: bezpieczeństwo i oparcie
Zauważanie tego, co daje poczucie bezpieczeństwa.
Pierwsze sposoby na odnalezienie oparcia w sobie i otoczeniu.
Tydzień 2: bliżej emocji
Rozpoznawanie uczuć, także lęku i złości.
Poszukiwanie słów i sposobów na to, co dzieje się w środku.
Tydzień 3: własne mocne strony
Przyglądanie się temu, co dziecku wychodzi i co jest dla niego ważne.
Małe próby budowania pewności siebie.
Tydzień 4: razem z innymi
Empatia i przyjaźń, z miejscem na własne granice.
Ćwiczenie proszenia o wsparcie.
Tydzień 5: co dalej?
Cele i marzenia, które dziecko chce poznawać.
Zauważanie przebytej drogi i świętowanie rozwoju.
A po ostatniej stronie?
Przygoda nie musi kończyć się wraz z dniem 31.
Zostaje książka pełna osobistych odpowiedzi, do której można wrócić jak do
własnego zbioru podpowiedzi
W trudnej chwili może stać się punktem wyjścia do rozmowy i przypomnienia sobie tego, co było pomocne.
Miejsce na własny głos
Dziecko nie potrzebuje gotowej roli do odegrania.
Potrzebuje przestrzeni, by zauważać siebie, próbować i odkrywać własne możliwości.
Zacznijcie od dziesięciu minut razem.
Rise.Shine.Evolve. Zaproszenie, by
wstać
zabłysnąć
rozwijać się
Razem z ludźmi, którzy są obok.
Zobacz książkę na Amazon''')
html(392,'''World 02: kolejny poziom rodzinnej przygody
10 zabawnych opowiadań w czarno-białym świecie gry
Gdy podstawy już za wami, codzienność odblokowuje kolejne zadania.
Ekrany, poranne i wieczorne rutyny, prośby, które jakby nie docierały do uszu.
Czasem aż 27 powtórzeń tego samego polecenia. Brzmi znajomo?
Do tego kłótnie rodzeństwa, przykre słowa i myśli, które mówią o nas niezbyt życzliwie.
Odwołany plan też potrafi wywrócić dzień do góry nogami.
A internet dorzuca własne wyzwania: bezpieczeństwo i wiadomości, którym trudno ufać.
World 02 zaprasza rodzinę do dalszych ćwiczeń w formie opowieści i misji.
Krótkie historie prowadzą przez sprawy, które naprawdę pojawiają się w domu.
Z humorem, czarno-białą grafiką i językiem gry.
Pikselowe zombie? Niewidzialny spam? To dopiero początek.
Nawet niedźwiedź polarny grający w Minecraft może okazać się ważnym tropem.
Zwłaszcza gdy trzeba sprawdzić, czy film jest prawdziwy.
Po każdej historii przychodzi pora na prosty pomysł do wypróbowania.
Mała misja zamiast wielkiej przemowy
Czytajcie, rozmawiajcie, sprawdzajcie w życiu
Dla rodzin, które chcą zrobić miejsce na rozmowę w zwyczajnym dniu.
I dla dzieci, którym łatwiej wejść w temat przez przygodę niż przez pouczenie.
Jak działa pięciominutowa misja?
1. Przeczytajcie historię
Wejdźcie na kolejny krótki poziom rodzinnej przygody.
Zobaczcie, z czym mierzą się bohaterowie.
2. Zajrzyjcie do Neuro-Coaching Console
Poznajcie krótkie wyjaśnienie i kod wiedzy.
Porozmawiajcie przez 2 minuty.
Wybierzcie jedno narzędzie, które pasuje do waszego dnia.
3. Wypróbujcie je
Przenieście pomysł z opowieści do codziennej sytuacji.
Od nawyku do nowej reakcji
Każda misja podsuwa inny sposób przyjrzenia się codzienności.
Rutyny
można budować małymi krokami, łącząc
nowy nawyk
z czymś, co już robimy.
Gdy do głowy wpadają przykre słowa, przydaje się
teflonowa tarcza
jako obraz tego, czego nie trzeba zatrzymywać przy sobie.
Rodzinny statek
też potrzebuje współpracy, a nie tylko kapitana wydającego polecenia.
Inna perspektywa
może zmienić rozmowę. Wystarczy spojrzeć na zagadkę 6/9.
Mentalny spam
zaprasza do sprawdzania myśli, zanim uznamy je za prawdę.
Taniec zmiany kierunku
to sposób opowieści na rozczarowanie i odwołane plany.
Internet
ma także swoje
zakłócenia rzeczywistości
Warto ćwiczyć odróżnianie informacji od
fałszywych wiadomości
Poznajcie swoją drużynę
Nini wnosi radość nawet na trudniejszy poziom.
Alio ćwiczy wykrywanie prawdy wśród zaskakujących wiadomości.
Dilo przygląda się równowadze między ekranem a resztą dnia.
Luli wnosi logikę i pomaga szukać porozumienia.
Mimi kieruje rodzinnym statkiem, choć załoga miewa własne pomysły.
Poziomy 11–20
11. Pętla nawyku: jak łączyć nawyki i ułatwiać sobie start.
12. Nocny odpoczynek: opowieść o mózgowej zmywarce.
13. Wadliwe Wi-Fi: słuchanie i filtrowanie tego, co do nas dociera.
14. Teflonowa tarcza: co zrobić z przykrymi słowami.
15. Bunt na statku: wkład we wspólnotę i 10-minutowa mobilizacja.
16. Zagadka 6/9: różne perspektywy i teoria umysłu.
17. Mentalny spam: pierwsze kroki w krytycznym myśleniu.
18. Pikselowe zombie: ekrany i to, co książka nazywa dopaminowym wypaleniem.
19. Taniec zmiany kierunku: gdy plany się zmieniają i przychodzi rozczarowanie.
20. Zakłócona rzeczywistość: fałszywe wiadomości i sprawdzanie informacji.
Dlaczego taka forma?
Krótkie rozdziały mogą ułatwić start także dzieciom, które niechętnie sięgają po książkę.
Zabawne historie otwierają temat bez długiego wykładu.
Praktyczny pomysł po lekturze daje okazję, by od razu czegoś spróbować.
Kolejny poziom zaczyna się w zwyczajnym rodzinnym dniu.
Wybierzcie jedną historię i sprawdźcie, dokąd zaprowadzi was rozmowa.
Zobacz książkę na Amazon
Otwórz stronę książki na Amazon''')
(base/'native-proposals.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
html(393,'''World 01: rodzinne życie ma swoje poziomy
10 zabawnych historii w czarno-białej oprawie gry
Po szkole emocje czasem wysypują się razem z zawartością plecaka.
Wybuchy, nuda, „nie chce mi się” i drobne sprawy, które nagle robią się ogromne.
Gdy czasu jest mało, trudno znaleźć chwilę na długą rozmowę. Dlatego ta przygoda zaczyna się od krótkiej misji.
Poradnik codzienności w świecie opowieści i gry
Happy Makers zapraszają do historii o zmutowanych mrówkach, niewidzialnym atramencie i emocjonalnych wulkanach.
Pod przygodą kryją się znajome rodzinne sytuacje.
Pięciominutowa misja: historia, krótki kod i próba w życiu
Nie trzeba przerabiać całego tematu naraz.
Wystarczy wspólna lektura, 2 minuty rozmowy i jeden pomysł do wypróbowania.
Każdy poziom zostawia miejsce na wasze własne odpowiedzi.
Jak przejść misję?
1. Przeczytajcie przygodę
 i zobaczcie, co przydarzyło się rodzinie Happy Makers.
2. Otwórzcie Neuro-Coaching Console
 z krótkim kodem oraz prostymi wyjaśnieniami neuronów lustrzanych, ciała migdałowatego i błędów mózgu. Poświęćcie 2 minuty na rozmowę.
3. Zastosujcie pomysł
 w jednej zwyczajnej sytuacji.
Co można tu poćwiczyć?
Zauważanie emocji po całym dniu szkolnej samokontroli.
Sposoby na wybuchy złości i szukanie uspokojenia.
Ciekawość, gdy pojawia się nuda i trudno znaleźć motywację.
Podejście do odkładania zadań i wyczerpania.
Przyjaźń i małe gesty, które ją budują.
Higienę i codzienne dbanie o siebie.
Myślenie, że czegoś nie umiem jeszcze, zamiast że nie umiem wcale.
Drużyna gotowa do przygody
Nini ma tutaj 5 lat i przypomina emocjonalny wulkan brokatu.
Alio zakłada durszlak, który ma chronić jego myśli.
Dilo uważa obowiązki za wyjątkowo kiepskie zadania poboczne.
Luli znajduje w książkach portale do innych światów.
Mimi szuka telefonu, świecąc jego własną latarką.
Poziomy 1–10
1. Powrót ze szkoły: emocje po całym dniu i szukanie równowagi.
2. Lodowa tragedia: empatia i neurony lustrzane.
3. Niewidzialne punkty doświadczenia: błędy jako okazja do nauki.
4. Znudzony szpieg: ciekawość pomaga szukać nowego tropu.
5. Jaszczurka w salonie: złość i budzenie czarodzieja.
6. Hałas budowy: słowo „jeszcze” i otwartość na rozwój.
7. Bankrutująca roślina: przyjaźń potrzebuje małych wpłat.
8. Zabłocone Ferrari: dbanie o siebie i własne potrzeby.
9. Forteca brokułu: paliwo, cegły i codzienna energia.
10. Wampir energii: wyczerpanie i próba zrobienia trudnego zadania najpierw.
Dlaczego w formie opowieści?
Humor pomaga zacząć rozmowę o rzeczach, o których czasem trudno mówić wprost.
Krótkie misje mieszczą się w dniu, w którym dzieje się już bardzo dużo.
Język gry i czarno-biała grafika tworzą wspólny świat przygody.
Pomysły z książki można wypróbować i sprawdzić, co pasuje do waszej rodziny.
Zacznijcie od jednej historii. Reszta rozmowy może potoczyć się po swojemu.
Mały krok dzisiaj może stać się początkiem kolejnych prób.
Wejdźcie na pierwszy poziom razem.
Zobacz książkę na Amazon''')
html(419,'''Data obowiązywania:
1 stycznia 2025 r.
1. Jakie dane zbieramy
Podczas zapisu zbieramy następujące dane:
Imię.
Adres e-mail.
Preferencje dotyczące kontaktu.
2. W jakim celu wykorzystujemy dane
Wykorzystujemy dane w następujących celach:
Przesyłanie materiałów edukacyjnych i newslettera.
Zapewnienie dostępu do bezpłatnych zasobów.
Informowanie o usługach i premierach.
Ulepszanie naszych treści.
Wypełnianie obowiązków prawnych.
3. Udostępnianie danych
Nie sprzedajemy danych osobowych, nie handlujemy nimi ani nie przekazujemy ich innym podmiotom bez zgody, z wyjątkiem przypadków opisanych w tej polityce lub wymaganych przez prawo.
4. Bezpieczeństwo danych
Stosujemy środki mające chronić dane przed nieuprawnionym dostępem, zmianą, ujawnieniem i zniszczeniem. Hasła są szyfrowane i bezpiecznie przechowywane.
5. Twoje prawa
W związku z przetwarzaniem danych przysługują ci następujące prawa:
Prawo dostępu
na podstawie art. 15 RODO: możesz uzyskać dostęp do swoich danych osobowych.
Prawo do sprostowania
na podstawie art. 16 RODO: możesz żądać poprawienia nieprawidłowych danych.
Prawo do usunięcia
na podstawie art. 17 RODO: możesz żądać usunięcia danych.
Prawo do ograniczenia przetwarzania
na podstawie art. 18 RODO: możesz żądać ograniczenia przetwarzania danych.
Prawo do przenoszenia danych
na podstawie art. 20 RODO: możesz żądać przeniesienia swoich danych.
Prawo sprzeciwu
na podstawie art. 21 RODO: możesz sprzeciwić się przetwarzaniu danych.
Prawo wycofania zgody
możesz w dowolnej chwili wycofać zgodę i wypisać się z newslettera.
Prawo wniesienia skargi
możesz złożyć skargę do Urzędu Ochrony Danych Osobowych.
6. Podstawy prawne przetwarzania
Przetwarzamy dane na następujących podstawach:
Zgoda, art. 6 ust. 1 lit. a RODO
w przypadku newslettera i dostępu do społeczności.
Prawnie uzasadniony interes, art. 6 ust. 1 lit. f RODO
w celu poprawy usług i rozwoju treści.
7. Okres przechowywania danych
Przechowujemy dane nie dłużej, niż jest to potrzebne do realizacji celu lub wymagane przez prawo. Dane newslettera przechowujemy do czasu wypisania się z niego.
8. Przekazywanie danych do innych państw
Dane mogą być przekazywane do innych państw. W takich przypadkach zapewniamy zabezpieczenia zgodne z rozdziałem V RODO.
9. Kontakt i inspektor ochrony danych
W sprawach danych osobowych skontaktuj się z nami:
rise.shine.evolve@gmail.com
Informacje Urzędu Ochrony Danych Osobowych:
https://uodo.gov.pl
Niniejsza polityka jest zgodna z GDPR, RODO i CCPA.
Rise.Shine.Evolve''')
(base/'native-proposals.json').write_text(json.dumps(p,ensure_ascii=False,indent=2)+'\n')
notes=[]
for u in units.values():
 if 'OWNER_GATE' in u.get('safety_consent','') and not u['id']=='dynamic.0419':
  if u['id'] in p:notes.append({'id':u['id'],'kind':'claim_reframing','reason':'Brief wskazuje nieudokumentowane twierdzenie o bezpieczeństwie, fizjologii, skuteczności, natychmiastowym efekcie albo gwarancji. Propozycja ujmuje je jako metaforę, próbę, możliwość lub obserwację bez zwiększania siły obietnicy. Wymagany backcheck źródła i decyzja publikacyjna właściciela.'})
notes.extend([{'id':'dynamic.0394','kind':'approved_identity_migration','reason':'Zastosowano zatwierdzony polski tytuł ŚWIĘTA SĄ TEŻ PO DRODZE zamiast starej tożsamości opakowania. W tej jednostce brief nie zawiera podtytułu ani hasła głównego, więc ich nie dodano.'},{'ids':['dynamic.0377','dynamic.0393'],'kind':'owner_gate','reason':'Zachowano konflikt źródła: Nini ma 4 lata w portrecie i 5 lat w panelu World 01. Nie rozstrzygano wieku.'},{'id':'dynamic.0419','kind':'legal_owner_gate','reason':'Konserwatywnie zachowano deklaracje źródłowe dotyczące zgodności, inspektora, szyfrowania, retencji, podstaw i transferów. Nie są to ustalenia autora lokalizacji ani potwierdzenie prawne.'}])
(base/'change-notes.json').write_text(json.dumps(notes,ensure_ascii=False,indent=2)+'\n')
import hashlib
expected={i for i,u in units.items() if not u['function'].startswith('Chroniony literal')}
print('count',len(p),'expected',len(expected),'missing',sorted(expected-set(p)),'extra',sorted(set(p)-expected))
print('sha256',hashlib.sha256((base/'native-proposals.json').read_bytes()).hexdigest())
