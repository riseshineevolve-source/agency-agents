/* One experience, distinct formats. Preserve existing legacy book modals and navigation. */
(function(){
'use strict';
let opener=null;
const publishedBookIds=new Set(['level-up-brain-world02','level-up-brain','confident-adventure']);
const existingBookFormats={
  'level-up-brain-world02':{book:'/library/world-02/',app:null},
  'level-up-brain':{book:'/library/world-01/',app:null},
  'confident-adventure':{book:'/library/confident-adventure/',app:'/adventure-app/'}
};
let publishedCatalogPromise = null;
function loadPublishedCatalog(){
  if(!publishedCatalogPromise) publishedCatalogPromise=fetch('/data/rse-product-catalog.json')
    .then(response=>{if(!response.ok)throw new Error('Catalog unavailable');return response.json();});
  return publishedCatalogPromise;
}
async function enhanceExistingBookModal(id){
  const body=document.getElementById('full-screen-book-details-content');
  const info=existingBookFormats[id];
  if(!body||!info)return;
  body.querySelector('.hm-modal-formats')?.remove();
  // One source of purchasing truth: remove historical hard-coded Amazon buttons
  // that are already inside the editorial book story before adding the verified
  // format chooser below. Keep non-retail controls such as View Infographic.
  const legacyAmazon = Array.from(body.querySelectorAll('button[onclick], a[href]'));
  for (const node of legacyAmazon) {
    const target = (node.getAttribute('onclick') || '') + ' ' + (node.getAttribute('href') || '');
    if (!/https:\/\/(?:www\.)?amazon\.com\//i.test(target)) continue;
    const wrapper = node.parentElement;
    node.remove();
    if (wrapper && wrapper !== body && wrapper.children.length === 0 &&
        !wrapper.textContent.trim()) wrapper.remove();
  }
  // Avoid leaving an unsupported hard-sell sentence just above the new chooser.
  body.querySelectorAll('p').forEach(p => {
    const copy = (p.textContent || '').trim();
    if (/^HIT ["“]?BUY NOW["”]?/i.test(copy) ||
        /^EQUIP YOUR CHILD WITH REAL-LIFE SKILLS THAT WILL PAY OFF FOR A LIFETIME/i.test(copy)) p.remove();
  });
  const strip=document.createElement('section');
  strip.className='hm-modal-formats';
  strip.setAttribute('aria-label','Choose where to get the book or app');
  const heading=document.createElement('h3');
  heading.className='hm-modal-formats__heading';
  heading.textContent='CHOOSE YOUR FORMAT';
  strip.appendChild(heading);
  const hint=document.createElement('p');
  hint.className='hm-modal-formats__hint';
  hint.textContent='One adventure, separate editions. Each format has its own availability.';
  strip.appendChild(hint);
  const row=document.createElement('div');
  row.className='hm-modal-formats__row';
  const book=document.createElement('div');
  book.className='hm-modal-formats__option';
  book.textContent='BOOK · Available on Amazon';
  row.appendChild(book);
  const app=document.createElement('span');
  app.className='hm-modal-formats__option hm-modal-formats__option--planned';
  app.textContent=info.app?'ANDROID APP · In development':'APP · Not released';
  row.appendChild(app);
  strip.appendChild(row);
  body.appendChild(strip);
  try{
    const data=await loadPublishedCatalog();
    const idMap={'level-up-brain-world02':'rse-level-up-world-02',
      'level-up-brain':'rse-level-up-world-01',
      'confident-adventure':'rse-confident-adventure-book'};
    const product=data.products.find(p=>p.id===idMap[id]);
    const url=product?.distribution?.storeUrl;
    if(product?.status!=='available'||!/^https:\/\/(?:www\.)?amazon\.com\//i.test(url||''))return;
    // Replace the text label with ONE verified retailer option, below the story.
    const link=document.createElement('a');
    link.className='hm-modal-formats__option hm-modal-formats__option--buy';
    link.href=url;
    link.target='_blank';
    link.rel='noopener noreferrer';
    link.textContent='BOOK · View on Amazon ↗';
    book.replaceWith(link);
  }catch(_){
    // Existing published book overview remains readable without storefront data.
    book.textContent='BOOK · Published (see edition details)';
  }
}
function init(){
  const dialog=document.getElementById('hm-detective-details');
  if(dialog&&dialog.parentElement!==document.body)document.body.appendChild(dialog);
  if(dialog){
    dialog.addEventListener('close',function(){
      if(history.state?.hmCaseDialog===true)history.back();
      if(opener&&opener.isConnected&&typeof opener.focus==='function')opener.focus();
      opener=null;
    });
    dialog.addEventListener('click',function(e){if(e.target===dialog)dialog.close();});
    window.addEventListener('popstate',function(event){
      if(dialog.open&&event.state?.hmCaseDialog!==true)dialog.close();
    });
  }
  document.addEventListener('click',function(event){
    const close=event.target.closest('[data-hm-case-close]');
    if(close&&dialog?.open){event.preventDefault();dialog.close();return;}
    const open=event.target.closest('[data-hm-case-open]');
    if(open){
      if(event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
      if(!dialog||typeof dialog.showModal!=='function')return;
      event.preventDefault();
      opener=open;
      if(!dialog.open){
        const state=history.state&&typeof history.state==='object'?history.state:{};
        history.pushState({...state,hmCaseDialog:true},'',location.href);
        dialog.showModal();
      }
      return;
    }
    const original=event.target.closest('[data-hm-original-book]');
    if(!original||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
    const id=original.getAttribute('data-hm-original-book');
    if(!publishedBookIds.has(id)||typeof window.showBookDetailsFullScreen!=='function')return;
    event.preventDefault();
    window.showBookDetailsFullScreen(id);
    enhanceExistingBookModal(id);
  });
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
