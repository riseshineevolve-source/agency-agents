from pathlib import Path
import json,re,hashlib,subprocess,shutil
ROOT=Path('website-source');OUT=Path('website-dynamic')
rows=json.loads((OUT/'analysis-units.json').read_text());source=json.loads((OUT/'source.json').read_text());occ=json.loads((OUT/'occurrences.json').read_text());known={x['text']:x['id'] for x in rows};static={x['text']:x['id'] for x in json.load(open('website-work/analysis-units.json'))};supp=[]
protected_names={'The Confident, Mindful & Happy Me Adventure','Level Up Your Brain - World 01','Level Up Your Brain - World 02','Happy Me Adventures','Before Christmas Slips By','Project Unstoppable','Optical Animals','Optical Halloween','Detective Academy','THE HAPPY MAKERS PRESENT','Amazon','Google Play','Android','App Store'}
def add(value,item,scope,kind,tokens=None):
 if not re.search('[A-Za-z]',value):return
 if value in protected_names:
  item.update({'protected_identity':True,'value':value});supp.append(item);return
 if value in static:
  item.update({'id':static[value],'value':value,'static_duplicate':True});supp.append(item);return
 if value in known:sid=known[value]
 else:
  sid=f'dynamic.{len(rows)+1:04d}';known[value]=sid
  rows.append({'id':sid,'text':value,'kind':kind,'scope':scope,'first_page':item['page'],'source_ref':item['page']+':'+str(item.get('pointer',item.get('start')))})
  source['segments'].append({'id':sid,'text':value,'protected':False,'protected_tokens':tokens or []})
 item.update({'id':sid,'value':value});supp.append(item)
# JSON customer-facing data, all internal status/URL/IDs remain untouched.
allowed={'title','eyebrow','subtitle','hook','intro','label','text','ending','statusText','question','answer'}
for path in ['data/rse-format-options.json']:
 data=json.loads((ROOT/path).read_text())
 def walk(v,p=()):
  if isinstance(v,dict):
   for k,c in v.items():walk(c,p+(k,))
  elif isinstance(v,list):
   for i,c in enumerate(v):walk(c,p+(i,))
  elif isinstance(v,str) and p[-1] in allowed:
   add(v,{'page':path,'kind':'json','pointer':list(p)},'format-data','product-format')
 walk(data)
# Template literals: preserve exact expressions via explicit source-bound tokens.
quarantine=json.load(open(OUT/'unresolved-templates.json'))
for item in quarantine:
 raw=item['raw']
 if raw.startswith(('`inp${','`sel${','`word-${')):continue
 exprs=[];parts=[];i=1;pos=1
 while i<len(raw)-1:
  if raw.startswith('${',i):
   st=i;depth=1;i+=2;q=None
   while i<len(raw)-1 and depth:
    ch=raw[i]
    if q:
     if ch=='\\':i+=2;continue
     if ch==q:q=None
    elif ch in '\"\'`':q=ch
    elif ch=='{':depth+=1
    elif ch=='}':depth-=1
    i+=1
   exprs.append(raw[st:i]);parts.extend([raw[pos:st],'{js_expr_'+str(len(exprs))+'}']);pos=i
  else:i+=1
 parts.append(raw[pos:-1]);val=''.join(parts)
 # For conditional English literals inside expressions, target nested literal spans,
 # not parent template. No overlapping replacements.
 if any('Wheel spinning...' in x or 'Filter updated.' in x for x in exprs):
  for m in re.finditer(r'"(?:[^"\\]|\\.)*"',raw):
   try:v=json.loads(m.group())
   except:continue
   if v.startswith(('Wheel spinning...','Filter updated.')):
    add(v,{'page':item['page'],'kind':'js','start':item['start']+m.start(),'end':item['start']+m.end(),'quote':'"','raw':m.group()},'template-ui','ui')
  continue
 val=subprocess.run(['node','-e',"const vm=require('vm');console.log(JSON.stringify(vm.runInNewContext('`'+process.argv[1]+'`',Object.create(null),{timeout:100})))",val],text=True,capture_output=True,check=True).stdout
 val=json.loads(val)
 tokens=[f'{{js_expr_{i+1}}}' for i in range(len(exprs))]
 tokens+=re.findall(r'<(?:[^>\"\']|\"[^\"]*\"|\'[^\']*\')*>',val)
 add(val,{'page':item['page'],'kind':'js-template','start':item['start'],'end':item['end'],'quote':'`','raw':raw,'expressions':exprs},'template-ui','template-ui',list(dict.fromkeys(tokens)))
# Explicit customer-visible shared runtime literal allowlist, source matched exactly.
ui=["View on Amazon ↗","Open Google Play ↗","Open App Store ↗"," — open verified listing on ","Available — select edition on ","Explore the full book story","READ · BOOK","PLAY · APP","Choose your format","Book and app are separate editions. Each has its own availability; links appear only for verified releases.","Book edition","Current publication status. A retailer link appears only when a real edition is available.","App edition","Current app development and download status. No store link until a verified release.","Close product details","Jump to book &amp; app formats ↓","What the experience includes","Good to know","ONE STORY · CHOOSE YOUR FORMAT","Available formats","Book and app are different editions. ","Each has its own availability; a purchase link appears only after publication."]
path='assets/js/rse-experience-hub.js';code=(ROOT/path).read_text()
for value in ui:
 matched=False
 for q in ['\"',"'"]:
  literal=q+value.replace('\\','\\\\').replace(q,'\\'+q)+q
  for m in re.finditer(re.escape(literal),code):
   add(value,{'page':path,'kind':'js','start':m.start(),'end':m.end(),'quote':q,'raw':literal},'shared-product-runtime','ui');matched=True
 if not matched:
  # Source text may be inside an HTML fragment literal; replace only visible text
  # offsets within that literal, preserving all tags/attributes.
  for m in re.finditer(re.escape(value),code):
   add(value,{'page':path,'kind':'literal-fragment','start':m.start(),'end':m.end(),'raw':value},'shared-product-runtime','ui');matched=True
  if not matched:print('unmatched reviewed runtime string',value)
(OUT/'analysis-units.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n')
(OUT/'source.json').write_text(json.dumps(source,ensure_ascii=False,indent=2)+'\n')
(OUT/'supplement-occurrences.json').write_text(json.dumps(supp,ensure_ascii=False,indent=2)+'\n')
(OUT/'previous-source-425.sha256').write_text('82a0ac43b08af4d3194fbfcad4fe636820613b7c32976c246ac656c88487940a\n')
if (OUT/'run').exists():shutil.move(OUT/'run',OUT/'source-425-run')
print({'total_units':len(rows),'supplement_occurrences':len(supp),'new_units':len(rows)-425})
