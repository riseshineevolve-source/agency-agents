/* Single customer story for every product family: from Home, Kids, Teens and Library.
   Product-specific SEO pages remain accessible without JavaScript.
   Storefront actions are rendered only from reviewed product records. */
(() => {
  "use strict";
  const DATA_URL = "/pl/data/rse-format-options.json";
  const MARKETPLACES = {
    Amazon: ["www.amazon.com", "amazon.com"],
    "Google Play": ["play.google.com"],
    "App Store": ["apps.apple.com"]
  };
  let catalogPromise = null;
  let activeDialog = null;
  let activeTrigger = null;
  let pending = false;

  function fetchCatalog() {
    if (!catalogPromise) {
      catalogPromise = fetch(DATA_URL, { credentials: "same-origin" }).then(r => {
        if (!r.ok) throw new Error("Experience information unavailable");
        return r.json();
      }).catch(err => {
        catalogPromise = null;
        throw err;
      });
    }
    return catalogPromise;
  }

  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text != null) node.textContent = text;
    return node;
  }

  function safeStoreUrl(format) {
    if (format.status !== "available" || !format.storeUrl) return null;
    try {
      const url = new URL(format.storeUrl);
      if (url.protocol !== "https:" ||
          !MARKETPLACES[format.channel]?.includes(url.hostname)) return null;
      return url.href;
    } catch (_) { return null; }
  }

  function lineIcon(kind) {
    const namespace = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(namespace, "svg");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("width", "22");
    svg.setAttribute("height", "22");
    svg.setAttribute("fill", "none");
    svg.setAttribute("stroke", "currentColor");
    svg.setAttribute("stroke-width", "1.8");
    svg.setAttribute("stroke-linecap", "round");
    svg.setAttribute("stroke-linejoin", "round");
    svg.setAttribute("aria-hidden", "true");
    svg.classList.add("rse-unified__format-icon");
    const path = document.createElementNS(namespace, "path");
    path.setAttribute("d", kind === "read"
      ? "M12 20c-3-2.2-6.5-3-10-2.5V4c3.5-.5 7 0 10 2.5 3-2.5 6.5-3 10-2.5v13.5c-3.5-.5-7 .3-10 2.5Zm0-13.5V20"
      : "M6 7h12a3 3 0 0 1 3 3v4a3 3 0 0 1-3 3h-2l-2 3-2-3h-1l-2 3-2-3H6a3 3 0 0 1-3-3v-4a3 3 0 0 1 3-3Zm2 3v4m-2-2h4m6-1h.01m2 2h.01");
    svg.appendChild(path);
    return svg;
  }

  function formatGroup(section, heading, options) {
    if (!options?.length) return null;
    const group = el("section", "rse-unified__group");
    group.setAttribute("aria-label", heading);
    const title = el("h4", "rse-unified__group-title", heading);
    title.prepend(lineIcon(section));
    group.appendChild(title);
    const linkedOffers = new Set();
    options.forEach(opt => {
      const row = el("div", "rse-unified__format");
      const details = el("div", "rse-unified__format-copy");
      details.appendChild(el("strong", "rse-unified__format-label", opt.label));
      if (opt.channel && opt.status !== "planned")
        details.appendChild(el("span", "rse-unified__format-channel", opt.channel));
      row.appendChild(details);
      const url = safeStoreUrl(opt);
      if (url && !linkedOffers.has(url)) {
        linkedOffers.add(url);
        const link = el("a", "rse-unified__store-link",
          opt.channel === "Amazon" ? "Otwórz Amazon ↗" :
          opt.channel === "Google Play" ? "Otwórz Google Play ↗" : "Otwórz App Store ↗");
        link.href = url;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        link.setAttribute("aria-label", opt.label + "Otwórz potwierdzoną stronę produktu w " + opt.channel);
        row.appendChild(link);
      } else {
        const status = el("span", "rse-unified__availability",
          url ? "Dostępne. Wybierz wydanie w " + opt.channel : opt.statusText);
        status.setAttribute("aria-label", opt.label + ": " + opt.statusText);
        if (opt.status === "planned") status.classList.add("rse-unified__availability--planned");
        row.appendChild(status);
      }
      group.appendChild(row);
    });
    return group;
  }

  function removeUnsafeMarkup(container) {
    container.querySelectorAll("script, iframe, form, button, object, embed, video").forEach(node => node.remove());
    container.querySelectorAll("*").forEach(node => {
      Array.from(node.attributes).forEach(attr => {
        if (/^on/i.test(attr.name) || attr.name === "style") node.removeAttribute(attr.name);
      });
      if (node.hasAttribute("id")) node.removeAttribute("id");
      if (node.hasAttribute("href")) {
        const href = node.getAttribute("href") || "";
        if (!href.startsWith("/") && !href.startsWith("#")) node.removeAttribute("href");
      }
      if (node.hasAttribute("src")) {
        const path = node.getAttribute("src") || "";
        if (!path.startsWith("/assets/images/")) node.removeAttribute("src");
      }
    });
  }

  async function renderEditorial(dialog, experience) {
    const host = dialog.querySelector(".rse-unified__editorial");
    host.replaceChildren();
    if (experience.editorialSource === "owner-approved-detective-dossier") {
      // Clone the owner's graphic-novel dossier into the ONE shared dialog.
      // The original hidden source dialog is not opened by customer entrypoints.
      let source = null;
      // The same approved 5-image dossier must work from Kids/Adults too,
      // where the old hidden Home/Library markup does not exist.
      if (experience.editorialUrl === "/pl/assets/content/rse-detective-dossier.txt") {
        try {
          const response = await fetch(experience.editorialUrl, { credentials: "same-origin" });
          if (!response.ok) throw new Error("Detective dossier unavailable");
          const parsed = new DOMParser().parseFromString(await response.text(), "text/html");
          source = parsed.body.querySelector(".hm-case-dialog__inner");
        } catch (_) { /* Keep the approved inline source as a legacy fallback. */ }
      }
      if (!source) source = document.querySelector("#hm-detective-details .hm-case-dialog__inner");
      if (source) {
        const dossier = source.cloneNode(true);
        dossier.querySelectorAll(".hm-case-dialog__close,.hm-case-dialog__header,.hm-format-switch,.hm-case-dialog__status").forEach(node => node.remove());
        removeUnsafeMarkup(dossier);
        const panel = el("section", "rse-unified__detective-dossier");
        panel.setAttribute("aria-label", "Inside Detective Academy");
        panel.appendChild(dossier);
        host.appendChild(panel);
        host.hidden = false;
        return true;
      }
    }
    if (experience.editorialUrl) {
      try {
        if (!/^\/pl\/assets\/content\/rse-(happy-me|world-01|world-02)-editorial\.txt$/.test(experience.editorialUrl))
          throw new Error("Unapproved editorial source");
        const response = await fetch(experience.editorialUrl, { credentials: "same-origin" });
        if (!response.ok) throw new Error("Rich story unavailable");
        const markup = await response.text();
        const parsed = new DOMParser().parseFromString(markup, "text/html");
        const rich = parsed.body.querySelector(".rse-rich-story");
        if (!rich) throw new Error("No readable rich story");
        removeUnsafeMarkup(rich);
        const details = el("details", "rse-unified__longform");
        const summary = el("summary", "rse-unified__longform-summary", "Zobacz pełny opis książki");
        const inside = el("div", "rse-unified__rich-content");
        inside.appendChild(document.importNode(rich, true));
        details.append(summary, inside);
        host.appendChild(details);
        host.hidden = false;
        return true;
      } catch (_) { /* Editorial summary and formats remain visible. */ }
    }
    host.hidden = true;
    return false;
  }

  async function render(dialog, experience) {
    dialog.scrollTop = 0;
    const h = dialog.querySelector("#rse-unified-title");
    const cover = dialog.querySelector(".rse-unified__cover");
    const approvedCover = typeof experience.cover === "string" &&
      experience.cover.startsWith("/assets/images/");
    if (approvedCover && experience.editorialSource !== "owner-approved-detective-dossier") {
      cover.src = experience.cover;
      cover.alt = experience.title + (experience.formats?.read?.[0]?.status === "available"
        ? " published book cover" : " approved preview artwork");
      cover.hidden = false;
    } else {
      cover.removeAttribute("src");
      cover.hidden = true;
    }
    const subtitle = dialog.querySelector(".rse-unified__subtitle");
    const kicker = dialog.querySelector(".rse-unified__kicker");
    const hook = dialog.querySelector(".rse-unified__hook");
    const body = dialog.querySelector(".rse-unified__intro");
    const features = dialog.querySelector(".rse-unified__features");
    const end = dialog.querySelector(".rse-unified__ending");
    const faqSection = dialog.querySelector(".rse-unified__faq");
    const faqList = dialog.querySelector(".rse-unified__faq-list");
    const groups = dialog.querySelector(".rse-unified__groups");
    kicker.textContent = experience.eyebrow || "RISE.SHINE.EVOLVE.";
    h.textContent = experience.title;
    subtitle.textContent = experience.subtitle || "";
    subtitle.hidden = !experience.subtitle;
    hook.textContent = experience.hook || "";
    body.textContent = experience.intro || "";
    features.replaceChildren();
    (experience.features || []).forEach((item, index) => {
      const article = el("article", "rse-unified__feature");
      article.appendChild(el("span", "rse-unified__feature-index",
        String(index + 1).padStart(2, "0")));
      article.appendChild(el("h3", "", item.label));
      article.appendChild(el("p", "", item.text));
      features.appendChild(article);
    });
    end.textContent = experience.ending || "";
    faqList.replaceChildren();
    (experience.faq || []).forEach(({ question, answer }) => {
      if (!question || !answer) return;
      const item = el("details", "rse-unified__faq-item");
      item.appendChild(el("summary", "rse-unified__faq-question", question));
      item.appendChild(el("p", "rse-unified__faq-answer", answer));
      faqList.appendChild(item);
    });
    faqSection.hidden = faqList.children.length === 0;
    groups.replaceChildren();
    const read = formatGroup("read", "Czytaj", experience.formats?.read);
    const play = formatGroup("play", "Graj", experience.formats?.play);
    if (read) groups.appendChild(read);
    if (play) groups.appendChild(play);
    groups.classList.toggle("rse-unified__groups--single", !!read !== !!play);
    const chosen = dialog.querySelector("#rse-unified-chooser-title");
    const intro = dialog.querySelector(".rse-unified__choose-intro");
    if (read && play) {
      chosen.textContent = "Wybierz format";
      intro.textContent = "Książka i aplikacja to odrębne wydania. Każde ma własny status, a linki pojawiają się po potwierdzeniu premiery.";
    } else if (read) {
      chosen.textContent = "Wydanie książkowe";
      intro.textContent = "Tu znajdziesz bieżący status publikacji. Link do sprzedawcy pojawi się, gdy wydanie będzie rzeczywiście dostępne.";
    } else {
      chosen.textContent = "Wydanie aplikacji";
      intro.textContent = "Tu znajdziesz bieżący status prac i pobierania. Link do sklepu pojawi się po potwierdzeniu premiery.";
    }
    const isDetective = experience.editorialSource === "owner-approved-detective-dossier";
    dialog.classList.toggle("rse-unified--detective", isDetective);
    features.parentElement.hidden = isDetective;
    const rich = await renderEditorial(dialog, experience);
    dialog.querySelector(".rse-unified__jump").hidden = !rich;
  }

  function createDialog() {
    const dialog = document.createElement("dialog");
    dialog.id = "rse-unified-experience-dialog";
    dialog.className = "rse-unified";
    dialog.setAttribute("aria-labelledby", "rse-unified-title");
    dialog.setAttribute("aria-describedby", "rse-unified-intro");
    dialog.innerHTML =
      '<div class="rse-unified__panel">' +
      '<button type="button" class="rse-unified__close" aria-label="Zamknij szczegóły produktu">×</button>' +
      '<header class="rse-unified__hero"><p class="rse-unified__kicker"></p>' +
      '<img class="rse-unified__cover" alt="" hidden><h2 id="rse-unified-title"></h2><p class="rse-unified__subtitle"></p>' +
      '<p class="rse-unified__hook"></p><p class="rse-unified__intro" id="rse-unified-intro"></p>' +
      '<a class="rse-unified__jump" href="#rse-unified-chooser-title" hidden>Książka &amp; aplikacja ↓</a></header>' +
      '<section class="rse-unified__story" aria-label="Co znajdziesz w środku">' +
      '<div class="rse-unified__features"></div><p class="rse-unified__ending"></p></section>' +
      '<div class="rse-unified__editorial" hidden></div>' +
      '<section class="rse-unified__faq" aria-labelledby="rse-unified-faq-heading" hidden>' +
      '<h3 id="rse-unified-faq-heading">Dobrze wiedzieć</h3>' +
      '<div class="rse-unified__faq-list"></div></section>' +
      '<section class="rse-unified__chooser" aria-labelledby="rse-unified-chooser-title">' +
      '<p class="rse-unified__section-label">Jedna historia. Wybierz swój format.</p>' +
      '<h3 id="rse-unified-chooser-title">Dostępne formaty</h3>' +
      '<p class="rse-unified__choose-intro">Książka i aplikacja to odrębne wydania. ' +
      'Każde wydanie ma własną dostępność. Link do zakupu pojawia się dopiero po publikacji.</p>' +
      '<div class="rse-unified__groups"></div></section></div>';
    document.body.appendChild(dialog);
    dialog.querySelector(".rse-unified__close").addEventListener("click", () => dialog.close());
    dialog.addEventListener("click", e => { if (e.target === dialog) dialog.close(); });
    dialog.addEventListener("close", () => {
      if (history.state?.rseExperienceDialog === true) history.back();
      if (activeTrigger?.isConnected) activeTrigger.focus();
      activeTrigger = null;
    });
    window.addEventListener("popstate", e => {
      if (dialog.open && e.state?.rseExperienceDialog !== true) dialog.close();
    });
    return dialog;
  }

  async function openExperience(trigger) {
    if (pending || activeDialog?.open) return;
    pending = true;
    try {
      const data = await fetchCatalog();
      const experience = data.experiences?.[trigger.dataset.rseExperience];
      if (!experience || !experience.formats) throw new Error("Experience not configured");
      if (!activeDialog) activeDialog = createDialog();
      await render(activeDialog, experience);
      activeTrigger = trigger;
      const state = (history.state && typeof history.state === "object") ? history.state : {};
      history.pushState({ ...state, rseExperienceDialog: true }, "", location.href);
      activeDialog.showModal();
      activeDialog.querySelector(".rse-unified__close").focus();
    } catch (_) {
      window.location.assign(trigger.getAttribute("href") || "/library/");
    } finally { pending = false; }
  }

  function init() {
    document.addEventListener("click", event => {
      const anchor = event.target.closest("a[data-rse-experience]");
      if (!anchor || event.defaultPrevented || event.button !== 0 ||
          event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      openExperience(anchor);
    });
  }
  // Legacy handoff: the occasional old campaign entry opens THIS story,
  // never the former independent full-screen-book-details modal.
  window.RSEExperienceHub = Object.freeze({
    open(key) {
      if (!/^[a-z0-9-]+$/.test(key)) return;
      const trigger = document.querySelector('a[data-rse-experience="' + key + '"]');
      if (trigger) openExperience(trigger);
    }
  });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
